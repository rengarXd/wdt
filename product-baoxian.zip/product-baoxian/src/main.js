// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
// import 'babel-polyfill'
import Vue from 'vue'
import App from './App'
import router from './router'
import fastclick from 'fastclick'

fastclick.attach(document.body)

Vue.config.silent = true;
Vue.config.productionTip = false;

Vue.prototype._ajax = function (Service, request, callback){
  let that = this;
  let a = {
    "Request": {
      "Service": Service,
      "User": "wdt",
      "SN": "123456",
      "Source": "mobile",
      "Parameters": request
    }
  };
  let datass = { RequestParam: JSON.stringify(a) };
  $.post(window.baoxianurl, datass, function (data) {
    if (data.Response.Success == 'False') {
      //提示
      layer.open({
        content: data.Response.Fails[0].Message
        ,skin: 'msg'
        ,time: 1
      });
      layer.closeAll();
    } else {
      if (typeof callback == 'function') {
        callback(data.Response.Result);
      }
    }
  });
}
Vue.prototype.isCrowTeam = function (callback){
  if (localStorage.currentLoginMemberKey){
    let that = this;
    that._ajax('GetCrowdKey',{
      "currentLoginMemberKey":localStorage.currentLoginMemberKey
    }, function (data) {
      localStorage.crowdKey = data.crowdKey;
      localStorage.userCrowdStatus = data.userCrowdStatus;
      if (typeof callback == 'function')
        callback(data);
    })
  }else {
    this.$router.push('/team_list_head/team_list_create');
  }
}
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
})
