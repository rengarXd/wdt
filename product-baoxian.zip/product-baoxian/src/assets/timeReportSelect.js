/**
 * Created by aaa on 2017/6/22.
 */
//将时间转换成标准时间
var parserDate = function (date) {
  var t = Date.parse(date);
  if (!isNaN(t)) {
    return new Date(Date.parse(date.replace(/-/g, "/")));
  } else {
    return new Date();
  }
};

function AddYear(times) {
  // 先获取当前时间
  var curDate = (times).getTime();
  // 将半年的时间单位换算成毫秒
  var oneYear = 365 * 24 * 3600 * 1000;
  var pastResult = curDate + oneYear;  // 一年前的时间（毫秒单位）
  var date = new Date();
  //console.log(now.getTime());
  if(pastResult >= date.getTime()){
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    return y + '-' + m + '-' + d;
  }else {
    // 日期函数，定义起点为半年前
    var pastDate = new Date(pastResult),
      pastYear = pastDate.getFullYear(),
      pastMonth = pastDate.getMonth() + 1,
      pastDay = pastDate.getDate();
    return pastYear + '-' + pastMonth + '-' + pastDay;
  }
}
function MinYear(times) {
  // 先获取当前时间
  var curDate = (times).getTime();
  // 将半年的时间单位换算成毫秒
  var oneYear = 365 * 24 * 3600 * 1000;
  var pastResult = curDate - oneYear;  // 一年前的时间（毫秒单位）
  // 日期函数，定义起点为半年前
  var pastDate = new Date(pastResult),
    pastYear = pastDate.getFullYear(),
    pastMonth = pastDate.getMonth() + 1,
    pastDay = pastDate.getDate();
  return pastYear + '-' + pastMonth + '-' + pastDay;
}
var start = {
  format: 'YYYY-MM',
  minDate: '2011-01-01', //设定最小日期为当前日期
  isinitVal:false,
  festival:true,
  ishmsVal:false,
  maxDate: $.nowDate({DD:0}), //最大日期
  choosefun: function(elem, val, date){
    //console.log(AddYear(parserDate(val+'-01 00:00:00')));
    end.minDate = val+'-01'; //开始日选好后，重置结束日的最小日期
    end.maxDate = AddYear(parserDate(val+'-01 00:00:00'));
    endDates();
  }
};
var end = {
  format: 'YYYY-MM',
  minDate: '2011-01-01', //设定最小日期为当前日期
  isinitVal:true,
  festival:true,
//            hmsSetVal:{hh:00,mm:12,ss:00},
  maxDate: $.nowDate(), //最大日期
  choosefun: function(elem, val, date){
    //console.log(this.maxDate);
    start.minDate = MinYear(parserDate(val+'-01 00:00:00'))
    start.maxDate = val+'-01'; //将结束日的初始值设定为开始日的最大日期
  }
};
//这里是日期联动的关键
function endDates() {
  //将结束日期的事件改成 false 即可
  end.trigger = false;
  $("#inpend").jeDate(end);
}
$('#inpstart').jeDate(start);
$('#inpend').jeDate(end);
