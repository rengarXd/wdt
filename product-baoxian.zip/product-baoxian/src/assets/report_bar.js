/**
 * Created by aaa on 2017/6/22.
 */
"use strict";

var productList = null,
  dataList = null,
  datas = new Object();
$(document).ready(function () {
  $("#inpstart").val(parseInt($.nowDate().substr(0, 4)) - 1 + $.nowDate().substring(4, 7));
//            $('body').on('touchmove',function (event) {
//                event.preventDefault();
//            })
  search();
});
function getRequest() {
  var url = location.search; //获取url中"?"符后的字串
  var theRequest = new Object();
  if (url.indexOf("?") != -1) {
    var str = url.substr(1);
    var strs = str.split("&");
    for (var i = 0; i < strs.length; i++) {
      theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
    }
  }
  return theRequest;
}

function selectProduct(obj) {
  var ii = $(obj).val();
  dataList = productList[ii].dataList;
  //console.log(productList[ii].productName);
  //chartDataFuncion('销售件数');
  var $avtive = $(".chooser-list").find("li");
  $avtive.each(function (index, obj) {
    if ($(obj).attr('class') == 'action') {
      chartDataFuncion($(obj).html());
    }
  });
}

function search() {
  var companycode = getRequest().companyCode ? getRequest().companyCode : localStorage.companyCode;
  var tmsBranchCode = getRequest().tmsBranchCode ? getRequest().tmsBranchCode : localStorage.tmsBranchCode;
  //console.log(companycode + '===' + tmsBranchCode);
  var a = {
    "Request": {
      "Service": "ProductSaleTrend",
      "User": "wdt",
      "SN": "123456",
      "Source": "mobile",
      "Parameters": {
        "companyCode": companycode,
        "tmsBranchCode": tmsBranchCode,
        "startDate": $("#inpstart").val() + '-01',
        "endDate": $("#inpend").val() + '-01'
      }
    }
  };
  var datass = { RequestParam: JSON.stringify(a) };
  $.post(window.baoxianurl, datass, function (data) {
    //console.log(data.Response.Result);
    productList = data.Response.Result.productList;

    dataList = productList[0].dataList;
    var gettpl = document.getElementById('demo').innerHTML;
    laytpl(gettpl).render(productList, function (html) {
      document.getElementById('view').innerHTML = html;
      chartDataFuncion('销售件数');
      var $avtive = $(".chooser-list").find("li");
      $avtive.click(function () {
        $(this).addClass('action').siblings().removeClass('action');
        chartDataFuncion($(this).html());
      });
    });
  });
}

function chartDataFuncion(name) {
  if (name == '销售件数') {
    var saleCount = new Array();
    datas.name = '销售件数';
    datas.type = 'bar';
    datas.markLine = {
      data: [{ type: 'average', name: '平均值' }, { type: 'max', name: '最大值' }, { type: 'min', name: '最小值' }]
    };
    for (var i in dataList) {
      saleCount.push(parseFloat(dataList[i].saleCount));
    }
    datas.data = saleCount;
  } else {
    var saleAmount = new Array();
    datas.name = '销售金额';
    datas.type = 'bar';
    datas.markLine = {
      data: [{ type: 'average', name: '平均值' }, { type: 'max', name: '最大值' }, { type: 'min', name: '最小值' }]
    };
    for (var _i in dataList) {
      saleAmount.push(parseFloat(dataList[_i].saleAmount));
    }
    datas.data = saleAmount;
  }
  var month = new Array();
  for (var a in dataList) {
    month.push(dataList[a].month.substr(5));
  }
  Echarts(month, datas);
}

function Echarts(month, datas) {
  //console.log(JSON.stringify(datas));
  // 路径配置
  require.config({
    paths: {
      echarts: 'http://echarts.baidu.com/build/dist'
    }
  });

  // 使用
  require(['echarts', 'echarts/chart/bar' // 使用柱状图就加载bar模块，按需加载
  ], function (ec) {
    // 基于准备好的dom，初始化echarts图表
    var myChart = ec.init(document.getElementById('main'));

    var option = {
      // title : {
      //     text: '某地区蒸发量和降水量',
      //     subtext: '纯属虚构'
      // },
      tooltip: {
        trigger: 'axis'
      },
//                     legend: {
//                         data: ['销售件数', '销售金额']
//                     },
//                     toolbox: {
//                         show : true,
//                         feature : {
//                             mark : {show: true},
//                             dataView : {show: true, readOnly: false},
//                             magicType : {show: true, type: ['line', 'bar']},
//                             restore : {show: true},
//                             saveAsImage : {show: true}
//                         }
//                     },
      calculable: true,
      xAxis: [{
        name: '月份',
        nameTextStyle: {
          color: '#000'
        },
        type: 'category',
        data: month
      }],
      yAxis: [{
        name: datas.name,
        nameTextStyle: {
          color: '#000'
        },
        type: 'value'
      }],
      series: [datas]
    };
    // 为echarts对象加载数据
    myChart.setOption(option);
  });
}
//                                {
//                                    name:'销售件数',
//                                    type:'bar',
//                                    data:[2, 4, 7, 23, 26, 76, 135, 162, 32, 20, 6, 3],
//                                    markPoint : {
//                                        data : [
//                                            {type : 'max', name: '最大值'},
//                                            {type : 'min', name: '最小值'}
//                                        ]
//                                    },
//                                    markLine : {
//                                        data : [
//                                            {type : 'average', name: '平均值'},
//                                            {type : 'max', name: '最大值'},
//                                            {type : 'min', name: '最小值'}
//                                        ]
//                                    }
//                                },
//                            {
//                                name:'销售金额',
//                                type:'bar',
//                                data:[0, 0, 0, 0, 0, 70, 17, 18, 48011, 18, 6, 0],
//                                markPoint : {
//                                    data : [
//                                        {name : '年最高', value : 182.2, xAxis: 7, yAxis: 183, symbolSize:18},
//                                        {name : '年最低', value : 2.3, xAxis: 11, yAxis: 3}
//                                    ]
//                                },
//                                markLine : {
//                                    data : [
//                                        {type : 'average', name : '平均值'}
//                                    ]
//                                }
//                            }
