﻿// window.baoxianurl = 'http://192.168.0.104:8096/ClientService/WdtService.ashx'
window.baoxianurl = 'http://www.shoupolan.net.cn/ClientService/WdtService.ashx'
