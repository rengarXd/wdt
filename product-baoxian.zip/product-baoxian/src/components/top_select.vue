<template>
  <div>
    <div class="dialog-wrap" v-cloak v-if="bSign">
      <div class="dialog-cover" @click="closeMySelf"></div>
      <transition name="fade">
        <div class="head_list">
          <ul>
            <router-link tag="li" to="/team_work">
              查看业绩
            </router-link>
            <router-link tag="li" to="/team_delete">
              踢出成员
            </router-link>
            <router-link tag="li" to="/team_change">
              移交团队
            </router-link>
            <li @click="deleteTeam">解散团队</li>
          </ul>
        </div>
      </transition>
    </div>
  </div>
</template>

<script>
    export default {
        props: {
          bSign: {
            type: Boolean,
            default: false //默认
          },
        },
        data () {
            return {}
        },
        methods:{
          closeMySelf () {
            this.$emit('closeself')
          },
          deleteTeam () {
            var that = this;

            //询问框
            layer.open({
              content: '您确定要解散团队吗？'
              ,btn: ['确定', '不']
              ,yes: function(index){
                layer.close(index);
                //loading带文字
                layer.open({
                  type: 2
                  , content: '解散中'
                });
                that._ajax('CreateOrDeleteCrowd',{
                  "operation":'delete',
                  "companyCode":localStorage.companyCode,
                  "crowdCreatePersonCode":localStorage.tmsTsrId,
                  "crowdKey":localStorage.crowdKey
                },function (data) {
                  layer.closeAll();
                  localStorage.userCrowdStatus = '0';
                  that.$emit('reloadrender');
                  that.closeMySelf();
                  //提示
                  layer.open({
                    content: '解散成功，您现在不属于任何团队'
                    ,skin: 'msg'
                    ,time: 1
                    ,end:function () {
                        that.$router.replace('team_list_create')
                    }
                  });
                })
              }
            });
          },
          _ajax: function _ajax(Service, request, callback) {
            var that = this;
            var a = {
              "Request": {
                "Service": Service,
                "User": "wdt",
                "SN": "123456",
                "Source": "mobile",
                "Parameters": request
              }
            };
            var datass = { RequestParam: JSON.stringify(a) };
            $.post(window.baoxianurl, datass, function (data) {
              if (data.Response.Success == 'False') {
                //提示
                layer.open({
                  content: data.Response.Fails[0].Message
                  ,skin: 'msg'
                  ,time: 1
                });
                layer.closeAll();
              } else {
                if (typeof callback == 'function') {
                  callback(data.Response.Result);
                }
              }
            });
          }
        }
    }
</script>

<style scoped>
  .dialog-wrap {
    position: absolute;
    width: 100%;
    height: 100%;
    top:44px;
  }
  .dialog-cover {
    background: transparent;
    position: fixed;
    z-index: 5;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
  ul{
    list-style-type: none;
  }
  .head_list{
    position: absolute;
    right:0;
    top:0;
    background: rgba(0,0,0,0.5);
    z-index:10;
  }
  .head_list ul{
    padding: 0;
  }
  .head_list li{
    padding:8px 20px;
    color:#fff;
    /*margin-right: 5px;*/
    z-index:10;
  }
</style>
