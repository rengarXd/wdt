<template>
  <div>
    <div class="dialog-wrap">
      <div class="dialog-cover"  v-if="isShow" @click="closeSelf"></div>
      <transition name="fade">
        <div class="dialog-content"  v-if="isShow">
          <slot></slot>
        </div>
      </transition>
    </div>
  </div>
</template>

<script>

  export default {
    props: {
      isShow: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {

      }
    },
    methods: {
      closeSelf () {
        this.$emit('on-close')
      }
    }
  }
</script>

<style scoped>
  .drop-enter-active {
    transition: all .5s ease;
  }
  .drop-leave-active {
    transition: all .3s ease;
  }
  .drop-enter {
    transform: translateY(-500px);
  }
  .drop-leave-active {
    transform: translateY(-500px);
  }
  .dialog-wrap {
    position: fixed;
    width: 100%;
    height: 100%;
  }
  .dialog-cover {
    background: #000;
    opacity: .3;
    position: fixed;
    z-index: 5;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
  .dialog-content {
    width: 70%;
    position: fixed;
    max-height: 50%;
    overflow: auto;
    background: #fff;
    top: 30%;
    left: 45%;
    margin-left: -31%;
    z-index: 10;
    border: 1px solid #464068;
    border-radius: 5px;
    padding: 2%;
    line-height: 1.6;
  }
</style>
