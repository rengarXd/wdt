<template>
  <div>
    <div class="H-padding-vertical-bottom-10"></div>
    <div class="H-margin-horizontal-both-8 H-border-both-after">
      <div class="H-flexbox-horizontal">
        <span class="H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white H-font-size-16"><i class="iconfont icon-sousuo_sousuo H-theme-font-color-999"></i></span>
        <input type="search"  v-model="searchText" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="输入想要搜索的信息">
        <span v-if="isActive" @click="searchText = ''" class="H-icon H-vertical-middle H-padding-horizontal-right-10 H-theme-background-color-white"><i @click="searchBarClearBtn"  class="iconfont icon-guanbi H-theme-font-color-999"></i></span>
      </div>
    </div>
    <div class="H-padding-vertical-both-8 H-padding-horizontal-both-15 H-font-size-12 H-theme-font-color-999">
      您可以直接从以下列表中选或者在上面搜索框中搜索
    </div>
  </div>
</template>

<script>
    export default {
        data () {
            return {
              searchText:'',
              isActive:false,
            }
        },
        watch:{
          searchText : function(newVal, oldVal){
            console.log(newVal,oldVal);
            if (this.searchText == ''){
              this.isActive = false;
            }else {
              this.isActive = true;
            }
            if(newVal != oldVal){
              this.$emit('search-ajax',newVal)
            }
          },
        },
        methods:{
          searchBarClearBtn () {
            this.searchText = '';
            this.isActive = false;
          }
        }
    }
</script>

