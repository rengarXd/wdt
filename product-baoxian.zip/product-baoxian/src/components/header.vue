<template>
<div>
  <header class="H-header b_header_bg">
        <span @click="back" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-both-5 H-z-index-100"> <i class="iconfont icon-fanhui H-font-size-22 H-vertical-middle"></i>
        </span>
        <div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent"><slot></slot></div>
  </header>
  <div style="height: 45px"></div>
</div>
</template>
<script>
    export default {
        props:{
          backurl: {
            type: String,
            default: ''
          },
        },
        methods:{
          back () {
            if (this.backurl){
              this.$router.replace({ path: this.backurl})
            }else {

            }
          }
        }
    }
</script>
<style scoped>
  .H-header{
    position: fixed;
    left:0;
    right: 0;
    z-index: 10000;
  }
</style>
