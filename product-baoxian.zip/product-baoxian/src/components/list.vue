<template>
  <mt-loadmore :top-method="loadTop" :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" bottomLoadingText="" bottomPullText="" @bottom-status-change="handleBotChange"  topPullText="" topLoadingText="加载中.." ref="loadmore"  @top-status-change="handleTopChange">
    <slot></slot>
    <div slot="top" class="mint-loadmore-top H-center-all">
      <span v-show="topStatus === 'loading'"><img src="../assets/images/loading.gif" width="20"></span>
    </div>
    <div slot="bottom" class="mint-loadmore-bottom H-center-all">
      <span v-show="botStatus === 'loading'" style="height: 30px"><img src="../assets/images/loading.gif" width="20"></span>
    </div>
  </mt-loadmore>
</template>

<script>
  import { Loadmore } from 'mint-ui'
    export default {
        name: '',
        components : {
          'mt-loadmore': Loadmore
        },
        props: {
          isDone: {
            type: Boolean,
            default: false
          }
        },
        data () {
            return {
              topStatus:'',
              allLoaded:false,
              botStatus:'',
            }
        },
        methods:{
          handleTopChange(status) {
            this.topStatus = status;
          },
          handleBotChange(status) {
            console.log(status)
            this.botStatus = status;
          },
          loadTop () {
            this.$emit('load-top')
          },
          loadBottom() {
            this.$emit('load-bottom')
          },
          bottomDone() {
//            console.log('111');
            this.botStatus = '';
//            this.allLoaded = !this.allLoaded;
//            this.$refs.loadmore.onBottomLoaded();
          },
          topDone(){
            this.$refs.loadmore.onTopLoaded();
          },
          allBottomDone() {
            this.allLoaded = true;
            this.$refs.loadmore.onBottomLoaded();
          }
        }
    }
</script>

<style>

</style>
