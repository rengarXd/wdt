<template>
  <div class="H-padding-10 H-theme-background-color-white chat">
    <div class="H-search H-flexbox-horizontal H-box-sizing-border-box">
      <input type="search" name="keyword" v-model="chatthisText" placeholder="请输入.." class="H-border-none H-width-100-percent H-theme-background-color-f4f4f4 H-flex-item H-font-size-16 H-padding-horizontal-both-10 H-padding-vertical-both-5">
      <!--<span v-if="text != ''" @click="text = ''"  class="H-icon H-vertical-middle H-padding-horizontal-right-10 H-float-right "><i class="iconfont icon-guanbi H-theme-font-color-999"></i></span>-->
      <button @click="sendBtn" class="H-button H-margin-horizontal-left-10 H-font-size-15 H-outline-none H-padding-vertical-both-5 H-padding-horizontal-both-20 H-theme-background-color1 H-theme-font-color-white H-theme-border-color1 H-theme-border-color1-click H-theme-background-color1-click H-theme-font-color1-click" style="min-width:0;">发送</button>
    </div>
  </div>
</template>

<script>
    export default {
        name: '',
//        props: {
//          text: {
//            type: String,
//            default: '' //默认
//          },
//        },
        data () {
            return {
              chatthisText:''
            }
        },
//        watch: {
//          chatthisText () {
//            return this.text;
//          }
//        },
        methods:{
          sendBtn () {
            if (this.chatthisText != ''){
              this.$emit('chat-text',this.chatthisText)
              this.chatthisText = ''
            }else {
              //提示
              layer.open({
                content: '发送内容不能为空'
                ,skin: 'msg'
                ,time: 1
              });
            }
          }
        }
    }
</script>

<style scoped>
  .chat{
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
  }
</style>
