<template>
  <div class="logincontent" :style="contentStyle">
    <header class="H-header header_bg">
      <router-link tag="span" to="/" class="H-icon H-z-index-1000 H-position-relative H-display-inline-block H-float-right H-vertical-middle H-padding-horizontal-right-10"> <i class="iconfont icon-guanbi  H-font-size-20  H-vertical-middle"></i>
      </router-link>
      <div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-position-absolute H-width-100-percent"></div>
    </header>
    <div id="logo"></div>
    <div class="content-text">
      <div class="H-flexbox-horizontal H-border-both-after item-inp H-theme-background-color-white" >
        <span class="H-icon H-vertical-middle H-padding-horizontal-left-10  H-theme-font-color-black"><i class="iconfont icon-baoxian1 H-font-size-18 H-vertical-middle"></i></span>
        <!--<input type="text" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-10" placeholder="用户名...">-->
        <select class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-theme-background-color-white H-padding-10 " v-model="companyCode">
          <option v-for="(item,index) in companyList" :value="item.companyCode" >{{ item.companyName }}</option>
        </select>
      </div>
      <div class="H-flexbox-horizontal H-border-both-after item-inp H-theme-background-color-white" >
        <span class="H-icon H-vertical-middle H-padding-horizontal-left-10  H-theme-font-color-black"><i class="H-iconfont H-icon-user H-font-size-18 H-vertical-middle"></i></span>
        <input type="text" v-model="usernameModel" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-10" placeholder="用户名...">
      </div>
      <div class="H-flexbox-horizontal H-border-both-after item-inp H-theme-background-color-white" >
        <span class="H-icon H-vertical-middle H-padding-horizontal-left-10  H-theme-font-color-black"><i class="iconfont icon-mima H-font-size-18 H-vertical-middle"></i></span>
        <input v-if="passwordType == 'password'" type="password" v-model="passwordModel" placeholder="密码（6-12位）" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-10">
        <input v-else  type="text" v-model="passwordModel" placeholder="密码（6-12位）" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-10">
        <span @click="changePasswordType" class="H-icon H-vertical-middle H-padding-horizontal-right-15 H-theme-background-color-white H-theme-font-color-black"><i class="iconfont icon-207 H-font-size-18 H-vertical-middle"></i></span>
      </div>
      <p style="padding-right: 10px;color: white" class=" H-text-align-right" v-html="userErrors.errorText"></p>
      <p style="padding-right: 10px;color: white" class=" H-text-align-right" v-html="passwordErrors.errorText"></p>
      <p style="padding-right: 10px;color: white" class=" H-text-align-right" v-html="errorText"></p>
      <div class="login_btn" @click="onLogin">登&nbsp;录</div>
    </div>
  </div>
</template>

<script>
    export default {
      name: 'login',
      data () {
          return {
            usernameModel: '',
            passwordModel: '',
            errorText: '',
            passwordType: 'password',
            companyList: [],
            companyCode: '', //用户所选公司代码
            contentStyle:''
          }
      },
      computed: {
        userErrors: function userErrors() {
          let errorText, status;
          if (!/^[\w\W]+$/g.test(this.usernameModel)) {
            status = false;
            errorText = '用户名不能为空';
          } else {
            status = true;
            errorText = '';
            this.errorText = ''
          }
          if (!this.userFlag) {
            errorText = '';
            this.userFlag = true;
          }
          return {
            status: status,
            errorText: errorText
          };
        },
        passwordErrors: function passwordErrors() {
          let errorText, status;
          if (!/^[\w\W]+$/g.test(this.passwordModel)) {
            status = false;
            errorText = '密码不能为空';
          } else {
            status = true;
            errorText = '';
            this.errorText = ''
          }
          if (!this.passwordFlag) {
            errorText = '';
            this.passwordFlag = true;
          }
          return {
            status: status,
            errorText: errorText
          };
        }
      },
      created: function created() {
        this.contentStyle = "{ width: "+ document.body.offsetWidth +"px,height:"+document.body.offsetHeight +"px }"
        this.company();
        $('.logincontent').on('touchmove',function (event) {
          event.preventDefault();
        })
      },
      methods: {
        changePasswordType: function changePasswordType() {
          if (this.passwordType == 'password') {
            this.passwordType = 'text';
          } else {
            this.passwordType = 'password';
          }
        },
        onLogin: function onLogin() {
          var that = this;
          //            || !that.passwordErrors.status
          if (!that.userErrors.status) {
            if (!that.userErros.errorText) {
              that.errorText = '用户名填写有误';
            }
            if (!that.passwordErrors.errorText) {
              that.errorText = '密码填写有误';
            }
          } else {
            that.errorText = '';
            //loading带文字
            layer.open({
              type: 2
              , content: '登录中'
            });
            //ajax
            that._ajax('UserLogin', {
              "companyCode": that.companyCode,
              "userAccount": that.usernameModel,
              "password": that.passwordModel
            }, function (data) {
              layer.closeAll();
              if (data.Fail) {
                that.errorText = data.Fail.Message;
                localStorage.clear();
              } else {
                that.errorText = '';
                localStorage.companyCode = that.companyCode;
                localStorage.companyName = data.companyName;
                localStorage.tmsBranchCode = data.tmsBranchCode;
                localStorage.userAccount = that.usernameModel;
                localStorage.tmsAuthor = data.tmsAuthor;
                localStorage.tmsTsrId = data.tmsTsrId;
                localStorage.tmsTsrName = data.tmsTsrName;
                localStorage.userCrowdStatus = data.userCrowdStatus;
                localStorage.crowdKey = data.crowdKey;
                localStorage.phone = data.phone;
                localStorage.currentLoginMemberKey = data.currentLoginMemberKey;
                that.$router.push({ name: 'main'});

//                            if (that.getRequest().type == '0'){
//                                if (data.tmsAuthor == '1'){
//                                    setTimeout(function () {
//                                        window.location.href = "./report_portal.html";
//                                    }, 300);
//                                }else {
//                                    //信息框
//                                    layer.open({
//                                        content: '抱歉，您没有查看报表的权限'
//                                        ,btn: '我知道了'
//                                        ,yes:function (index) {
//                                            layer.close(index);
//                                            window.location.href = "./login.html";
//                                        }
//                                    });
//                                }
//                            }else {
//                                setTimeout(function () {
//                                    window.location.href = "./My_customer.html";
//                                }, 300);
//                            }
              }
            });
          }
        },
        getRequest: function getRequest() {
          var url = location.search; //获取url中"?"符后的字串
          var theRequest = new Object();
          if (url.indexOf("?") != -1) {
            var str = url.substr(1);
            var strs = str.split("&");
            for (var i = 0; i < strs.length; i++) {
              theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
            }
          }
          return theRequest;
        },
        company: function company() {
          var that = this;
          that._ajax('GetInsuranceCompanyList', {
            "companyCode": ""
          }, function (data) {
            that.companyList = data.companyList;
            that.companyCode = data.companyList[0].companyCode;
            //console.log(JSON.stringify(data));
          });
        }
      }
    }
</script>

<style scoped>
.logincontent{
  position: fixed;
  top:0;
  bottom: 0;
  left:0;
  right: 0;
  overflow: hidden;
  background: url(../assets/images/login_new2.png) no-repeat;
  background-size: 100%;
}
.content-text{
  padding: 50px !important;
}
.header_bg{
  background-color: transparent;
}
#logo{
  padding: 80px 0;
  text-align: center;
  font-size: 1.4rem;
  color: #FFFFFF;
}
li{
  background:#fff;
}
.dec{text-align: center;}
.dec span{
  display: inline-block;
  width:70px;
  height: 5px;
}
.line1{
  background: #00FF41;
}
.line2{
  background: #0005FC;
}
.line3{
  background: #FF0000;
}
.item-inp{
  border: 1px solid #d6d6d6;
  margin:13px 0 !important;
  border-radius: 30px;
  color: #CCCCCC !important;
}
.aui-form-list{
  border:none !important;
  outline-width: 0;
}
.login_btn{
  min-width: 120px;
  padding: 10px 20px;
  text-align: center;
  border: 1px solid rgba(16, 175, 210, 0.82);
  border-radius: 4px;
  margin-top: 50px;
  color: #f6f6f6;
  width: auto !important;
  background: rgba(16, 175, 210, 0.82);
  border-radius: 30px;
}
.aui-content{
  padding: 50px !important;
}
.aui-list{
  background: transparent !important;
  color: white;
}
</style>
