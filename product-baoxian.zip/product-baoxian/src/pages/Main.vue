<template>
<div class="maincontent" :style="contentStyle">
  <div class="exit" id="exit" @click="exit">退出</div>
  <div class="wdt-title">网电通</div>
  <div class="wdt-content">
    <div class=" H-flexbox-horizontal" style="padding-top: 50px">
      <div class="H-flexbox-horizontal H-flex-item wdt-item d_active" @click="report">
        <span class="wdt-icon"><i class="iconfont icon-tubiao110"></i></span>
        <div class="H-flex-item wdt-text">查看报表</div>
      </div>
      <router-link tag="div" to="/default/1" class="H-flexbox-horizontal H-flex-item wdt-item d_active">
        <span class="wdt-icon"><i class="iconfont icon-zaixianjiaoliu"></i></span>
        <div class="H-flex-item wdt-text">交流中心</div>
      </router-link>
    </div>
    <div class=" H-flexbox-horizontal">
      <div class="H-flexbox-horizontal H-flex-item wdt-item d_active" @click="turn('./proposal/My_customer.html')">
        <span class="wdt-icon"><i class="iconfont icon-kehu1"></i></span>
        <div class="H-flex-item wdt-text">我的客户</div>
      </div>
      <div class="H-flexbox-horizontal H-flex-item wdt-item d_active" @click="turnTeam">
        <span class="wdt-icon"><i class="iconfont icon-kehu"></i></span>
        <div class="H-flex-item wdt-text">我的团队</div>
      </div>
    </div>
    <div class=" H-flexbox-horizontal">
      <router-link tag="div" to="/Security_program" class="H-flexbox-horizontal H-flex-item wdt-item d_active">
        <span class="wdt-icon"><i class="iconfont icon-jihuashu"></i></span>
        <div class="H-flex-item wdt-text">制作计划书</div>
      </router-link>
      <div @click="turn('/answer_scene')" class="H-flexbox-horizontal H-flex-item wdt-item d_active">
        <span class="wdt-icon"><i class="iconfont icon-huashuguanli"></i></span>
        <div class="H-flex-item wdt-text">智能话术</div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
    export default {
        name: 'main',
        data () {
            return {
//              imgurl: { background: "url(" + require('../assets/images/index-bg2.jpg') + ") no-repeat;"},
              contentStyle:''
            }
        },
        mounted () {
          this.contentStyle = "{ width: "+ document.body.offsetWidth +"px,height:"+document.body.offsetHeight +"px }"
          if (localStorage.tmsBranchCode) {
            document.getElementById('exit').style.display = "block";
          }
          $('.maincontent').on('touchmove',function (event) {
            event.preventDefault();
          })
        },
        methods:{
          report () {
            let vm = this;
            if (localStorage.tmsBranchCode) {
              if (localStorage.tmsBranchCode && localStorage.tmsAuthor == '1') {
                vm.$router.push('report_index')
              }else {
                //信息框
                layer.open({
                  content: '抱歉，您没有查看报表的权限'
                  ,btn: '我知道了'
                });
              }
            }else {
              //信息框
              layer.open({
                content: '请先登陆'
                ,btn: '去登陆'
                ,yes: function(index){
                  layer.close(index)
                  vm.$router.push('login')
                }
              });
            }
          },
          turn (url) {
            let vm = this;
            if (localStorage.tmsBranchCode) {
              if (url.indexOf('.html') > 0) {
                window.location.href = url;
              }else {
                vm.$router.push(url)
              }
            }else {
              //信息框
              layer.open({
                content: '请先登陆'
                ,btn: '去登陆'
                ,yes: function(index){
                  layer.close(index)
                  vm.$router.push('login')
                }
              });
            }
          },
          turnTeam (){
            if (localStorage.tmsBranchCode) {
              let that = this;
              that.isCrowTeam(function (data) {
                if (data.crowdKey){
                  that.$router.replace('/team_list_head/team_list_body');
                }else {
                  that.$router.replace('/team_list_head/team_list_create');
                }
              });
            }else {
              //信息框
              let vm = this;
              layer.open({
                content: '请先登陆'
                ,btn: '去登陆'
                ,yes: function(index){
                  layer.close(index)
                  vm.$router.push('login')
                }
              });
            }
          },
          exit () {
            //询问框
            layer.open({
              content: '您确定要退出登录吗？'
              ,btn: ['退出', '不']
              ,yes: function(index){
                layer.close(index);
                localStorage.clear();
                document.getElementById('exit').style.display = "none";
              }
            });
          }
        }
    }
</script>
<style scoped>
  .maincontent{
    position: absolute;
    top:0;
    bottom: 0;
    left:0;
    right: 0;
    /*width:100%;*/
    /*height: 100%;*/
    overflow: hidden;
    background: url(../assets/images/index-bg2.jpg) no-repeat;
    background-size: 100%;
  }
  .exit{
    display: none;
    color: #FFFFFF;
    text-align: right;
    font-size: 1.6rem;
    position: absolute;
    top: 30px;
    right: 25px;
    z-index: 100;
  }
  .wdt-title{
    text-align: center;
    font-size: 3.5rem;
    padding-top: 22%;
    /*padding-bottom: 2.5rem;*/
    color: #FFFFFF;
  }
  .wdt-icon{
    width: 4rem;
    text-align: center;
    font-size:3rem;
    padding-left: 1rem;
  }
  .wdt-text{
    margin: auto;
    font-size: 1.8rem;
    padding-left: 1.3rem;
  }
  .wdt-content {
    padding: 0 5% 0 5%;
    color: #FFFFFF;
  }
  .wdt-item{
    /*border: 1px solid;*/
    /*border-radius: 40px;*/
    margin: 1.8rem 0;
  }
</style>
