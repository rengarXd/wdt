<template>
<div>
  <v-header backurl="team_list_head/team_list_create">创建团队</v-header>
  <div class="H-padding-vertical-bottom-10"></div>
  <div class="H-flexbox-horizontal H-margin-vertical-bottom-8">
    <span class="H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white H-font-size-16">团队名称</span><input v-model="crowdName" type="text" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="不能有特殊符号">
  </div>
  <div class="H-padding-horizontal-left-10 H-theme-font-color-red">{{errorMessage}}</div>
  <div class="H-padding-25">
    <div class="aui-btn-info login_btn" @click="localPref">创&nbsp;建</div>
  </div>
</div>

</template>

<script>
  import Header from '../../components/header'
    export default {
        name: '',
        components : {
          'v-header': Header
        },
        data () {
            return {
              crowdName:'',
              errorMessage:''
            }
        },
        methods:{
          localPref () {
            //loading带文字
            layer.open({
              type: 2,
              content: '创建中'
            });
            let that = this;
            let a = {
              "Request": {
                "Service": 'CreateOrDeleteCrowd',
                "User": "wdt",
                "SN": "123456",
                "Source": "mobile",
                "Parameters": {
                  crowdName:that.crowdName,
                  operation:'add',
                  crowdCreatePersonCode:localStorage.tmsTsrId,
                  companyCode:localStorage.companyCode,
                  crowdCreatePersonName:localStorage.tmsTsrName
                }
              }
            };
            let datass = { RequestParam: JSON.stringify(a) };
            $.post(window.baoxianurl, datass, function (data) {
              layer.closeAll();
              if (data.Response.Success == 'False') {
                that.errorMessage = data.Response.Fails[0].Message;

              } else {
                that.errorMessage = '';
                let datas = data.Response.Result;
                localStorage.userCrowdStatus = '2';
                localStorage.crowdKey = datas.crowdKey;
                localStorage.currentLoginMemberKey = datas.currentLoginMemberKey;
                //提示
                layer.open({
                  content: '创建成功！'
                  ,skin: 'msg'
                  ,time: 1
                  ,end:function () {
                    that.$router.push('team_list_head/team_list_body')
                  }
                });
//                console.log(data.Response.Result)
              }
            });
          }
        }
    }
</script>

<style scoped>
  .login_btn{
    min-width: 120px;
    outline-width:0;
    padding: 10px 20px;
    text-align: center;
    border-radius: 4px;
    color: #ffffff ;
    background-color: #03a9f4 !important;
  }
</style>
