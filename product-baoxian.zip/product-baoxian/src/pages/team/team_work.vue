<template>
<div>
  <v-header backurl="team_list_head/team_list_body">团队业绩</v-header>
  <!-- 上拉加载更多 -->
  <load-more :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" :bottomPullText='bottomText' :auto-fill="false"  @bottom-status-change="handleBottomChange"  ref="loadmore">
    <div class="H-theme-background-color-white H-font-size-12 H-padding-horizontal-left-10 H-padding-vertical-both-5 H-margin-vertical-bottom-10">
      <span class="H-font-size-14 H-theme-font-color-666"><span class="H-padding-horizontal-right-5"><i class="iconfont icon-kehu"></i></span>团队人数：</span>
      {{totalCount}}人
      <div class="H-padding-horizontal-both-20 H-padding-vertical-both-8">
        <div class="H-flexbox-horizontal">
          <div class="H-flex-item"><span class="title-text">总获客数量：</span><span class="H-theme-font-color-666">{{totalwinCustomerCount}}</span></div>
          <div class="H-flex-item"><span class="title-text">总成员生成计划书数量：</span><span class="H-theme-font-color-666">{{totalgenarateProposalCount}}</span></div>
        </div>
        <div class="H-flexbox-horizontal">
          <div class="H-flex-item"><span class="title-text">总历史订单量：</span><span class="H-theme-font-color-666">{{totalhistoryComeOrderCount}}</span></div>
          <div class="H-flex-item"><span class="title-text">总今日订单量：</span><span class="H-theme-font-color-666">{{totaltodayComeOrderCount}}</span></div>
        </div>
        <div class="H-flexbox-horizontal">
          <div class="H-flex-item"><span class="title-text">总今日拨打任务量：</span><span class="H-theme-font-color-666">{{totaltodaytotalCallCustomerCount}}</span></div>
        </div>
      </div>
    </div>
    <div v-for="item in list" class="H-theme-background-color-white H-padding-horizontal-both-20 H-padding-vertical-both-10 H-margin-vertical-bottom-3">
      <div class="H-channel-title H-flexbox-horizontal  H-vertical-middle H-border-vertical-bottom-after">
        <div class="H-channel-line H-theme-background-color-black H-padding-vertical-top-15 H-padding-horizontal-left-3  H-margin-horizontal-left-10"></div>
        <div class="H-channel-text H-theme-font-color-black H-flex-item H-font-size-16 H-theme-font-color-black H-padding-10  H-text-show-row-1">{{item.tmsName}}</div>
      </div>
      <div class="H-padding-10">
        <div class="H-flexbox-horizontal">
          <div class="H-flex-item"><span class="work-text">获客量：</span><span class="H-theme-font-color-666">{{item.winCustomerCount}}</span></div>
          <div class="H-flex-item"><span class="work-text">建议书数量：</span><span class="H-theme-font-color-666">{{item.genarateProposal}}</span></div>
        </div>
        <div class="H-flexbox-horizontal">
          <div class="H-flex-item"><span class="work-text">历史出单量：</span><span class="H-theme-font-color-666">{{item.historyComeOrderCount}}</span></div>
          <div class="H-flex-item"><span class="work-text">当天出单量：</span><span class="H-theme-font-color-666">{{item.todayComeOrderCount}}</span></div>
        </div>
        <div class="H-flexbox-horizontal">
          <div class="H-flex-item"><span class="work-text">当天拨打任务量：</span><span class="H-theme-font-color-666">{{item.todaytotalCallCustomerCount}}</span></div>
        </div>
      </div>
    </div>
    <div v-show="loading" slot="bottom" class="loading">
      <img src="../../assets/images/loading01.gif">
    </div>
  </load-more>
</div>
</template>

<script>
  import Header from '../../components/header'
//  import { Loadmore } from 'mint-ui'
  import List from '../../components/scroll_bottom'
    export default {
        name: 'team_work',
        components : {
          'v-header': Header,
          'LoadMore': List
        },
        data () {
            return {
              isFisrtGet:false,
              loading: false,
              allLoaded: false,
              bottomText: '上拉加载更多...',
              bottomStatus: '',
              pageNo: 1,
              pageCount:1,
              totalCount:'',
              totalwinCustomerCount:'',//总获客数量
              totalgenarateProposalCount:'',//总成员生成计划书数量
              totalhistoryComeOrderCount:'',//总历史订单量
              totaltodayComeOrderCount:'',//总今日订单量
              totaltodaytotalCallCustomerCount:'',//总今日拨打任务量
              list:[]
            }
        },
        created () {
          this.getDetails()
        },
        methods: {
          getDetails (callback) {
            let that = this;
            that._ajax('GetCrowdPerformanceList', {
              "pageIndex": 1,
              "pageSize": 10,
              "crowdKey": localStorage.crowdKey,
//              "currentLoginMemberKey":localStorage.currentLoginMemberKey
            }, function (data) {
              that.totalCount = data.totalCount;
              that.pageCount = data.pageCount
              that.totalwinCustomerCount = data.totalwinCustomerCount;
                that.totalgenarateProposalCount = data.totalgenarateProposalCount;
                that.totalhistoryComeOrderCount = data.totalhistoryComeOrderCount;
                that.totaltodayComeOrderCount = data.totaltodayComeOrderCount;
                that.totaltodaytotalCallCustomerCount = data.totaltodaytotalCallCustomerCount;
                that.list = data.crowdPerformanceList;
                if (typeof callback == 'function'){
                  callback()
                }
            })
          },
          handleBottomChange(status) {
            this.bottomStatus = status;
          },
//          loadTop() {
//            let vm = this;
//            vm.getDetails(()=>{
//              setTimeout(()=>{
//              vm.$refs.lists.topDone();
//              },300);
//            });
//          },
          loadBottom() {
            this.loading = true;
            this.pageNo += 1;   // 每次更迭加载的页数
            if (parseInt(this.pageNo) > parseInt(this.pageCount)) {
              // 当allLoaded = true时上拉加载停止
              this.loading = false;
              this.allLoaded = true;
              return;
            }
            let that = this;
            that._ajax('GetCrowdPerformanceList', {
              "pageIndex": that.pageNo,
              "pageSize": 10,
              "crowdKey": localStorage.crowdKey
            }, function (data) {
              that.totalCount = data.totalCount;

              that.totalwinCustomerCount = data.totalwinCustomerCount;
              that.totalgenarateProposalCount = data.totalgenarateProposalCount;
              that.totalhistoryComeOrderCount = data.totalhistoryComeOrderCount;
              that.totaltodayComeOrderCount = data.totaltodayComeOrderCount;
              that.totaltodaytotalCallCustomerCount = data.totaltodaytotalCallCustomerCount;
              that.list = that.list.concat(data.crowdPerformanceList);
            })
          }
        }
    }
</script>

<!--<style>-->
<!--@import "../../assets/css/Hui.css";-->
<!--</style>-->
<style scoped>
  .work-text{
    font-size: 1.5rem;
    color: #999;
  }
  .title-text {
    font-size: 1.3rem;
    color: #bcbcbc;
  }
</style>
