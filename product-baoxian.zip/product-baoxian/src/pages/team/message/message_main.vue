<template>
  <div>
    <header class="H-header b_header_bg">
        <span @click="back" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-both-5 H-z-index-100"> <i class="iconfont icon-fanhui H-font-size-22 H-vertical-middle"></i>
        </span>
      <div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">团队消息</div>
    </header>
    <div style="height: 45px"></div>
    <div class="H-theme-background-color-white H-font-size-12 H-padding-horizontal-left-10 H-padding-vertical-both-5 H-margin-vertical-bottom-5">
      <span class="H-font-size-14 H-theme-font-color-999">&nbsp;</span>
      <div class="H-float-right H-display-inline H-padding-horizontal-right-10">
        <span style="background-color: #ff7200;" >&nbsp;</span><span class=" H-padding-horizontal-left-8">其他人</span>
        <span style="background-color: #03aafe;" >&nbsp;</span><span class=" H-padding-horizontal-both-8">自己</span>
       </div>
    </div>
    <mt-loadmore :top-method="loadTop" :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" bottomLoadingText="" bottomPullText="" @bottom-status-change="handleBotChange"  topPullText="" topLoadingText="加载中.." ref="loadmore"  @top-status-change="handleTopChange">
      <div v-if="list.length">
        <div  v-for="item in list">
          <div class="animated fadeIn H-text-align-center H-theme-font-color-999 H-font-size-12 H-margin-horizontal-both-12 H-padding-vertical-top-15 H-padding-vertical-bottom-5">{{jsDateDiff(item.sendTime)}}</div>
          <div class="animated fadeIn H-theme-background-color-white H-border-both-after H-border-radius-12 H-margin-horizontal-both-12 H-margin-vertical-bottom-8">
            <div v-if="isMe(item.tmsTsrId)" class="H-channel-title  H-flexbox-horizontal H-theme-background-color-white H-vertical-middle" >
              <div class="H-channel-text   H-theme-font-color4 H-flex-item H-font-size-18 H-theme-font-color-black H-text-show-row-1 chense">
                <i style="color: #000;" class="iconfont icon-touxiang1 H-font-size-24"></i> {{item.senderName}}
              </div>
            </div>
            <div v-else class="H-channel-title  H-flexbox-horizontal H-theme-background-color-white H-vertical-middle" >
              <div class="H-channel-text   H-theme-font-color4 H-flex-item H-font-size-18 H-theme-font-color-black H-text-show-row-1 lanse">
                <i style="color: #000;" class="iconfont icon-shangchuantouxiang H-font-size-24"></i> {{item.senderName}}
              </div>
            </div>
            <div class="xy_border"></div>
            <div class="H-theme-font-color-999 H-font-size-15" style="padding:10px 20px 10px 20px;">
              {{item.content}}
            </div>
          </div>
        </div>
      </div>
      <!--<div v-else>-->
        <!--<div  class="H-center-all H-padding-25 H-theme-font-color-999">-->
          <!--暂无数据,请发消息-->
        <!--</div>-->
      <!--</div>-->
      <div slot="top" class="mint-loadmore-top H-center-all">
        <span v-show="topStatus === 'loading'"><img src="../../../assets/images/loading.gif" width="20"></span>
      </div>
      <div slot="bottom" class="mint-loadmore-bottom H-center-all">
        <span v-show="botStatus === 'loading'" style="height: 30px"><img src="../../../assets/images/loading.gif" width="20"></span>
      </div>

    </mt-loadmore>
    <div style="padding: 25px"></div>
    <v-chat v-if="isTeam"  @chat-text="chatInput"></v-chat>
  </div>
</template>

<script>
  import Header from '../../../components/header'
  import Chat_box from '../../../components/chat_box'
  import { Loadmore } from 'mint-ui';
  export default {
    name: 'team_main',
    components : {
      'v-header':Header,
      'v-chat':Chat_box,
      'mt-loadmore': Loadmore
    },
    data () {
      return {
        topStatus:'',
        pageIndex:1,
        totalCount:'',
        allLoaded:false,
        botStatus:'',
        list:[]
      }
    },
    computed:{
      isTeam () {
        if (parseInt(localStorage.userCrowdStatus)){
          return true;
        }else {
          return false;
        }
      }
    },
//    created () {
//      let vm = this;
//      vm.isCrowTeam(function (data) {
//        if (!data.crowdKey){
//          localStorage.userCrowdStatus = 0;
//          vm.$router.replace('/team_list_head/team_list_create')
//        }
//      });
//    },
    methods:{
      back () {
        let vm = this;
        vm.isCrowTeam(function (data) {
          if (data.userCrowdStatus){
            vm.$router.replace('/team_list_head/team_list_body')
          }else {
            vm.$router.replace('/team_list_head/team_list_create')
          }
        });
      },
      isMe (tmsTsrId) {
        if (tmsTsrId != localStorage.tmsTsrId)
          return true;
        else
          return false;
      },
      handleTopChange(status) {
        this.topStatus = status;
      },
      handleBotChange(status) {
        this.botStatus = status;
      },
      loadBottom () {
        let that = this;

        that._ajax('GetMessageInfo',{
          "receiveKey":localStorage.crowdKey,
          "senderKey":localStorage.currentLoginMemberKey,
          "pageSize": 10,
          "messageType":'1'
        },function (data) {
//          layer.closeAll();
          that.pageIndex = data.pageIndex;
          that.totalCount = data.totalCount;
          that.list = data.messageList;
          that.$nextTick(() => {
            that.allLoaded = false;
            that.$refs.loadmore.onBottomLoaded();
          })
          that.allLoaded = true;
        })
      },
      loadTop() {
        let that = this;
        if (that.pageIndex > 1){
          that.pageIndex -= 1;
        }else {
          //提示
          return layer.open({
            content: '没有更多数据！'
            ,skin: 'msg'
            ,time: 1
            ,end:function () {
              that.$refs.loadmore.onTopLoaded();
            }
          });
        }
        that._ajax('GetMessageInfo',{
          "receiveKey":localStorage.crowdKey,
          "senderKey":localStorage.currentLoginMemberKey,
          "pageIndex":that.pageIndex,
          "pageSize": 10,
          "messageType":'1'
        },function (data) {
          that.list = data.messageList.concat(that.list);
          that.$nextTick(() => {
            that.$refs.loadmore.onTopLoaded();
         })
        })
      },
      chatInput (val) {
//        layer.open({
//          type: 2,
//          content: '发送中，请稍后'
//        });
        let that = this;
        that._ajax('CreateOrDeleteMessage',{
          "operation":'add',
          "receiveKey":localStorage.crowdKey,
          "senderKey":localStorage.currentLoginMemberKey,
          "content":val,
          "messageType": 1,
        },function (data) {
          that.loadBottom()
//          layer.closeAll();
        })
      },
      jsDateDiff : function(publishTime) {
        let nowtime = (new Date).getTime();
        let secondNum = parseInt((nowtime - publishTime) / 1000);
        if (secondNum >= 0 && secondNum < 60) {
          return secondNum + "秒前"
        } else {
          if (secondNum >= 60 && secondNum < 3600) {
            let nTime = parseInt(secondNum / 60);
            return nTime + "分钟前"
          } else {
            if (secondNum >= 3600 && secondNum < 3600 * 24) {
              let nTime = parseInt(secondNum / 3600);
              return nTime + "小时前"
            } else {
              let nTime = parseInt(secondNum / 86400);
              return nTime + "天前"
            }
          }
        }
      },
    }
  }
</script>

<style scoped>
  @import "../../../assets/css/animate/animate.min.css";
</style>
<style scoped>
  .lanse {
    color: #03aafe;
    padding: 7px 7px 7px 16px;
  }
  .chense {
    color: #ff7200;
    padding: 7px 7px 7px 16px;
  }
  .xy_border {
    border-bottom: 1px solid #f0f0f0;
    margin-left: 20px;
    margin-right: 15px;
  }
</style>

<style scoped>
  .H-header{
    position: fixed;
    left:0;
    right: 0;
    z-index: 10000;
  }
</style>
