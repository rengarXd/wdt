<template>
  <div>
    <!--<v-header :backurl="backurl">{{ $route.params.tmsname }}</v-header>-->
    <header class="H-header b_header_bg">
        <span @click="back" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-both-5 H-z-index-100"> <i class="iconfont icon-fanhui H-font-size-22 H-vertical-middle"></i>
        </span>
      <div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">{{ $route.params.tmsname }}</div>
    </header>
    <div style="height: 45px"></div>
    <!--<v-header backurl="/team_list_head/team_list_body">{{$route.params.tmsname}}</v-header>-->
    <!--<div @click="loadTop" class="H-text-align-center H-theme-font-color-ccc">查看更多</div>-->
    <mt-loadmore :top-method="loadTop" :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" bottomLoadingText="" bottomPullText="" @bottom-status-change="handleBotChange"  ref="loadmore"  @top-status-change="handleTopChange">
    <div v-for="item in list">
      <div v-if="isMe(item.tmsTsrId)">
        <div class="H-padding-vertical-top-10 H-text-align-center H-font-size-12 H-theme-font-color-999">{{jsDateDiff(item.sendTime)}}</div>
        <div class="H-chatbox-receiver H-flexbox-horizontal H-padding-horizontal-both-10 H-box-sizing-border-box H-margin-vertical-top-10">
          <div class="">
            <span class="H-width-100-percent H-height-100-percent H-display-block"><i class="iconfont icon-touxiang1 H-font-size-36"></i></span>
          </div>
          <div class="H-chatbox-main H-flex-item H-flexbox-horizontal H-position-relative H-margin-horizontal-left-12">
            <div class="H-chatbox-content" style="max-width: 210px;">
              <div class="H-position-relative">
                <div class="H-chatbox-content-text H-font-size-16 H-padding-10 H-theme-background-color-black H-theme-font-color-white H-border-radius-12">{{item.content}}</div>
                <div class="H-chatbox-bugle H-theme-border-color-black H-position-absolute H-z-index-100 H-bugle-left"></div>
              </div>
            </div>
            <div class="H-chatbox-status H-flex-item H-padding-horizontal-both-10 H-box-sizing-border-box H-text-align-left H-padding-vertical-top-12"></div>
          </div>
        </div>
      </div>
      <div v-else>
        <div class="H-padding-vertical-top-10 H-text-align-center H-font-size-12 H-theme-font-color-999">{{jsDateDiff(item.sendTime)}}</div>
        <div class="H-chatbox-sender H-flexbox-horizontal H-padding-horizontal-both-10 H-box-sizing-border-box H-margin-vertical-top-10">
          <div class="H-chatbox-main H-flex-item H-flexbox-horizontal H-position-relative H-margin-horizontal-right-12">
            <div class="H-chatbox-status H-flex-item H-padding-horizontal-both-10 H-box-sizing-border-box H-text-align-right H-padding-vertical-top-12"></div>
            <div class="H-chatbox-content" style="max-width: 210px;">
              <div class="H-position-relative">
                <div class="H-chatbox-content-text H-font-size-16 H-padding-10 H-theme-background-color1 H-theme-font-color-white H-border-radius-12">{{item.content}}</div>
                <div class="H-chatbox-bugle H-theme-border-color1 H-position-absolute H-z-index-100 H-bugle-right"></div>
              </div>
            </div>
          </div>
          <div class="">
            <span class="H-width-100-percent H-height-100-percent H-display-block"><i class="iconfont icon-shangchuantouxiang H-font-size-36"></i></span>
          </div>
        </div>
      </div>
    </div>
      <div slot="top" class="mint-loadmore-top H-center-all">
        <span v-show="topStatus === 'loading'"><img src="../../../assets/images/loading.gif" width="20"></span>
      </div>
      <div slot="bottom" class="mint-loadmore-bottom H-center-all">
        <span v-show="botStatus === 'loading'"><img src="../../../assets/images/loading.gif" width="20"></span>
      </div>
    </mt-loadmore>
    <div style="padding: 25px"></div>
    <v-chat  @chat-text="chatInput"></v-chat>
  </div>
</template>

<script>
  import Header from '../../../components/header'
  import Chat_box from '../../../components/chat_box'
  import { Loadmore } from 'mint-ui';

  export default {
    name: 'team_main',
    components : {
      'v-header':Header,
      'v-chat':Chat_box,
      'mt-loadmore': Loadmore
    },
    data () {
      return {
        topStatus: '',
        allLoaded:false,
        botStatus:'',
        counter: 1, //当前页
        list:[]
      }
    },
//    computed : {
//      backUrl () {
//        let that = this;
//        that.isCrowTeam(function (crowdKey) {
//          if (crowdKey){
//            return '/team_list_head/team_list_body'
//          }else {
//            localStorage.userCrowdStatus = 0;
//            return '/team_list_head/team_list_create'
//          }
//        });
//      },
//    },
//    created () {
//      let vm = this;
//      vm.isCrowTeam(function (data) {
//        if (!data.crowdKey){
//          localStorage.userCrowdStatus = "";
//          vm.$router.replace('/team_list_head/team_list_create')
//        }
//      });
//    },
    methods:{
      back () {
        let vm = this;
        vm.isCrowTeam(function (data) {
          if (data.userCrowdStatus){
            vm.$router.replace('/team_list_head/team_list_body')
          }else {
            vm.$router.replace('/team_list_head/team_list_create')
          }
        });
      },
      handleTopChange(status) {
        this.topStatus = status;
      },
      isMe (tmsTsrId) {
        if (tmsTsrId != localStorage.tmsTsrId)
          return true;
        else
          return false;
      },
      handleBotChange(status) {
        this.botStatus = status;
      },
      loadTop() {
        let that = this;
        if (that.counter > 1){
          that.counter -= 1;
          that._ajax('GetMessageInfo',{
            "senderKey":that.$route.params.senderKey,
            "receiveKey":that.$route.params.receiveKey,
            "pageIndex":that.counter,
            "pageSize": 10,
            "messageType":'2'
          },function (data) {
            that.list = data.messageList.concat(that.list);
            that.$nextTick(() => {
              that.$refs.loadmore.onTopLoaded();
          })
          })
        }else {
          //提示
          return layer.open({
            content: '已经到底了！'
            ,skin: 'msg'
            ,time: 1
            ,end:function () {
              that.$refs.loadmore.onTopLoaded();
            }
          });
        }

      },
      loadBottom() {

        let that = this;
        that._ajax('GetMessageInfo',{
          "senderKey":that.$route.params.senderKey,
          "receiveKey":that.$route.params.receiveKey,
          "pageSize": 10,
          "messageType":'2'
        },function (data) {
//          that.pageCount = data.pageCount;
          that.counter = data.pageIndex;
          that.list = data.messageList;
          that.$nextTick(() => {
            that.allLoaded = false;
            that.$refs.loadmore.onBottomLoaded();
          })
          that.allLoaded = true;
        })
      },
      jsDateDiff : function(publishTime) {
        let nowtime = (new Date).getTime();
        let secondNum = parseInt((nowtime - publishTime) / 1000);
        if (secondNum >= 0 && secondNum < 60) {
          return secondNum + "秒前"
        } else {
          if (secondNum >= 60 && secondNum < 3600) {
            let nTime = parseInt(secondNum / 60);
            return nTime + "分钟前"
          } else {
            if (secondNum >= 3600 && secondNum < 3600 * 24) {
              let nTime = parseInt(secondNum / 3600);
              return nTime + "小时前"
            } else {
              let nTime = parseInt(secondNum / 86400);
              return nTime + "天前"
            }
          }
        }
      },
//      getMessage () {
//        let that = this;
//        that._ajax('GetMessageInfo',{
//          "senderKey":that.$route.params.senderKey,
//          "receiveKey":that.$route.params.receiveKey,
////          "pageIndex":1,
//          "pageSize": 10,
//          "messageType":'2'
//        },function (data) {
////          layer.closeAll();
//          that.counter = data.pageCount;
//          that.list = data.messageList;
//        })
//      },
      chatInput (val) {
        layer.open({
          type: 2,
          content: '发送中，请稍后'
        });
        let that = this;
        that._ajax('CreateOrDeleteMessage',{
          "operation":'add',
          "senderKey":that.$route.params.senderKey,
          "receiveKey":that.$route.params.receiveKey,
          "content":val,
          "messageType": 2,
        },function (data) {
          that.loadBottom();
          layer.closeAll();
        })
      }
    }
  }
</script>

<style scoped>
  .H-header{
    position: fixed;
    left:0;
    right: 0;
    z-index: 10000;
  }
</style>
