<template>
  <div>
    <v-header backurl="/team_join">申请加入团队</v-header>
    <div class="H-padding-vertical-bottom-10"></div>
    <div class="H-flexbox-horizontal H-margin-vertical-bottom-10">
      <textarea v-model="remark" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="申请说明..."></textarea>
    </div>
    <div class="H-padding-horizontal-left-10 H-theme-font-color-red">{{errorMessage}}</div>
    <div class="H-padding-25">
      <div class="aui-btn-info login_btn" @click="localPref">申请加入</div>
    </div>
  </div>
</template>

<script>
  import Header from '../../components/header'
  export default {
    name: 'team_join_remark',
    components : {
      'v-header': Header
    },
    data () {
      return {
        remark:'',
        errorMessage:''
      }
    },
    methods:{
      localPref () {
        //loading带文字
        layer.open({
          type: 2,
          content: '申请中'
        });
        var that = this;
        var a = {
          "Request": {
            "Service": 'ApplyToJoinCrowd',
            "User": "wdt",
            "SN": "123456",
            "Source": "mobile",
            "Parameters": {
              tmsTsrId:localStorage.tmsTsrId,
              companyCode:localStorage.companyCode,
              tmsName:localStorage.tmsTsrName,
              crowdKey:that.$route.params.crowdKey,
              remark:that.remark,
              phone:localStorage.phone
            }
          }
        };
        var datass = { RequestParam: JSON.stringify(a) };
        $.post(window.baoxianurl, datass, function (data) {
          layer.closeAll();
          if (data.Response.Success == 'False') {
            that.errorMessage = data.Response.Fails[0].Message;

          } else {
            that.errorMessage = '';
            var datas = data.Response.Result;
            //提示
            layer.open({
              content: '申请成功！'
              ,skin: 'msg'
              ,time: 1
              ,end:function () {
                localStorage.userCrowdStatus = '1';
                localStorage.crowdKey = datas.crowdKey;
                localStorage.currentLoginMemberKey = datas.currentLoginMemberKey;
                that.$router.push('/team_list_head/team_list_body')
              }
            });
          }
        });
      }
    }
  }
</script>

<style scoped>
  .login_btn{
    min-width: 120px;
    outline-width:0;
    padding: 10px 20px;
    text-align: center;
    border-radius: 4px;
    color: #ffffff ;
    background-color: #03a9f4 !important;
  }
</style>
