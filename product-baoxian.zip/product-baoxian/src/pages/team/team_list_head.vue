<template>
  <div>
    <header class="H-header b_header_bg">
      <router-link tag="span" to="/"  class="H-icon H-z-index-1000 H-position-relative H-display-inline-block H-float-left H-vertical-middle H-padding-horizontal-both-5"> <i class="iconfont icon-fanhui H-theme-font-color-white H-font-size-20  H-vertical-middle"></i>
      </router-link>
      <div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent" v-cloak>我的团队</div>
      <span  @click="isShowManageFunction" class="H-icon H-z-index-1000 H-position-relative H-display-inline-block H-float-right H-vertical-middle H-padding-horizontal-right-5"> <i class="iconfont H-icon-dot-more H-theme-font-color-white H-font-size-20  H-vertical-middle"></i>
      </span>
      <span v-if="isTeamMessage" @click="isTeamFunction" class="H-icon H-z-index-1000 H-position-relative H-display-inline-block H-float-right H-vertical-middle H-padding-horizontal-right-25">
        <span class="top-tip" v-if="parseInt(crowdMessageCount)"><label class=" H-vertical-middle">{{crowdMessageCount}}</label></span>
        <i class="iconfont icon-zaixianjiaoliu H-theme-font-color-white H-font-size-22  H-vertical-middle"></i>
      </span>
    </header>
    <top_select :b-sign="isShowManage" @reloadrender="renderDom"  @closeself="closeMyself('isShowManage')">

    </top_select>
    <router-view></router-view>
  </div>
</template>

<script>
  import Top_select from '../../components/top_select'
    export default {
        name: 'team_list_head',
        components : {
          'top_select': Top_select
        },
        data () {
            return {
              isShowManage:false,//是否显示队长管理菜单
              isManager:false,//是否为队长
              isTeamMessage:false,
              crowdMessageCount:0,
              endTime:''
            }
        },
        computed: {
          message_main () {
            return "/message_main/"
          }
        },
        mounted () {
          let vm = this;
          vm.renderDom();
        },
        methods:{
          renderDom () {
            if (localStorage.userCrowdStatus == '2') {
              this.isManager = true
              this.isTeamMessage = true
            }else if (localStorage.userCrowdStatus == '1') {
              this.isManager = false
              this.isTeamMessage = true
            }else {
              this.isManager = false
              this.isTeamMessage = false
            };
            let vm = this;
            vm._ajax('GetCrowdMemeberList',{
              "crowdKey": localStorage.crowdKey,
              "currentLoginMemberKey":localStorage.currentLoginMemberKey
            }, (data) => {
              vm.crowdMessageCount = data.crowdMessageCount;
          })
          },
          closeMyself (attr) {
            this[attr] = !this[attr];
          },
          isShowManageFunction () {
            let that = this;
            that.isCrowTeam(function (data) {
              console.log(data);
              if ('2' == data.userCrowdStatus) {
                that.isShowManage = true;
              }else if ('1' == data.userCrowdStatus) {
                that.exitTeam();
              }else {
                //提示
                layer.open({
                  content: '请先加入或创建一个团队！'
                  ,skin: 'msg'
                  ,time: 1
                });
              }
            });
          },
          isTeamFunction () {
            let vm = this;
            vm.isCrowTeam(function (data) {
              if (data.userCrowdStatus){
                vm.$router.replace(vm.message_main);
              }else {
                vm.$router.replace('/team_list_head/team_list_create');
              }
            });
          },
          exitTeam () {
            let vm = this;
            //询问框
            layer.open({
              content: '您确定要退出团队吗？'
              ,btn: ['退出', '不']
              ,yes: function(index){
                layer.close(index);
                //退出ajax
                vm._ajax('ExitCrowd',{
                  "companyCode":localStorage.companyCode,
                  "tmsTsrId":localStorage.tmsTsrId,
                  "crowdKey": localStorage.crowdKey,
                  "currentLoginMemberKey":localStorage.currentLoginMemberKey
                }, function(data) {
//                    clearInterval(this.endTime);
                  localStorage.userCrowdStatus = "";
                  //提示
                  layer.open({
                    content: '退出成功！'
                    ,skin: 'msg'
                    ,time: 1
                    ,end:function () {
                      vm.isTeamMessage = false;
                      vm.$router.replace('/team_list_head/team_list_create')
                    }
                  });
                })
              }
            });
          }
        }
    }
</script>

<style scoped>
  .top-tip{
    position: absolute;
    top: 0;
    left: 10px;
    width: 10px;
  }
  .top-tip label{
    width: 1.3rem;
    height: 1.3rem;
    display: inline-block;
    -webkit-border-radius: 100%;
    font-size: 1rem;
    color: #FFFFFF;
    background-color: red;
    text-align: center;
    line-height: 1.2;
  }
</style>
