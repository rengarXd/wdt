<template>
  <div>
    <v-header backurl="team_list_head/team_list_create">选择团队</v-header>
    <v-search @search-ajax="searchAjax"></v-search>
    <div class="H-padding-horizontal-both-10">
      <router-link tag="div" v-for="item in crowdList" :to="'/team_join_remark/'+ item.crowdKey" class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-margin-vertical-bottom-2 H-vertical-middle H-touch-active" >
        <input type="radio" name="types"  class="H-radio H-radio-null H-display-block H-vertical-align-middle H-font-size-18 H-theme-font-color4 H-border-radius-circle H-margin-horizontal-both-10">
        <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">
          {{item.crowdName}}
        </div>
      </router-link>
    </div>
  </div>
</template>

<script>
  import Header from '../../components/header'
  import Search from '../../components/search'
    export default {
        name: '',
        components : {
          'v-header': Header,
          'v-search': Search
        },
        data () {
            return {
              remarkurl:'1',

              crowdList:[]
            }
        },
        mounted () {
          this.renderDom()
        },
        methods:{
          renderDom () {
            let that = this;
//            //loading带文字
//            layer.open({
//              type: 2
//              , content: '加载中'
//            });
            that._ajax('GetCrowdList',{
              "pageIndex":1,
              "pageSize":10
            },function (data) {
//                layer.closeAll();
                that.crowdList = data.crowdList;
            })
          },
          searchAjax (whereVal) {
            let that = this;
            that._ajax('GetCrowdList',{
                "pageIndex":1,
                "pageSize":10,
                "where": whereVal
            },function (data) {
              that.crowdList = data.crowdList;
            })
          }
        }
    }
</script>

<style>

</style>
