<template>
  <div>
    <!-- 上拉加载更多 -->
    <load-more :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" :bottomPullText='bottomText' :auto-fill="false"  @bottom-status-change="handleBottomChange"  ref="loadmore">

    <div v-for="item in crowdMemberList" class="H-flexbox-horizontal H-box-sizing-border-box H-theme-background-color-white H-border-vertical-bottom-after H-clear-both H-padding-horizontal-both-10 H-padding-vertical-both-8 H-touch-active">
      <div style="width:50px;height:50px;">
        <span class="message-tip"><label class=" H-vertical-middle H-theme-background-color1" v-if="parseInt(item.messageCount)">{{item.messageCount}}</label></span>
        <span v-if="isMe(item.tmsTsrId)" @click="turnPerson(item.tmsName,item.crowdMemberKey,item.tmsTsrId)" class="H-width-100-percent H-height-100-percent H-display-block"><i class="iconfont icon-touxiang1 H-font-size-36"></i></span>
        <span v-else class="H-width-100-percent H-height-100-percent H-display-block"><i style="color: red;" class="iconfont icon-shangchuantouxiang H-font-size-36"></i></span>
        <!--<img src="../../assets/images/yuyi.png" class="H-width-100-percent H-height-100-percent H-display-block H-border-radius-circle H-border-both">-->
      </div>
      <div class="H-flex-item H-padding-horizontal-both-10 H-vertical-middle H-overflow-hidden">
        <div class="H-width-100-percent">
          <strong v-if="isMe(item.tmsTsrId)" @click="turnPerson(item.tmsName,item.crowdMemberKey,item.tmsTsrId)" class="H-font-weight-normal H-display-block H-font-weight-500 H-font-size-16 H-text-show-row-1">
            {{item.tmsName}}
          </strong>
          <strong v-else class="H-font-weight-normal H-display-block H-font-weight-500 H-font-size-16 H-theme-font-color-999 H-text-show-row-1">
            {{item.tmsName}}
          </strong>
          <div  class="H-theme-font-color-999 H-font-size-14 H-padding-vertical-top-3 H-text-show-row-1">联系方式：<a
            :href="tel">{{item.phone}}</a>
          </div>
        </div>
      </div>
      <div class="H-font-size-12 H-theme-font-color-999 white-space-nowrap H-text-align-right">
        <div v-if="item.isCeatePerson == '1'" class="H-badge  H-margin-vertical-top-8  H-padding-horizontal-left-10"><label class="H-display-inline-block H-vertical-middle H-theme-background-color2 H-theme-font-color-white H-font-size-12">队长</label></div>
        <div v-else-if="!isMe(item.tmsTsrId)" class="H-badge  H-margin-vertical-top-8  H-padding-horizontal-left-10"><label class="H-display-inline-block H-vertical-middle H-theme-background-color8 H-theme-font-color-white H-font-size-12">自己</label></div>
        <div v-else class="H-badge  H-margin-vertical-top-8  H-padding-horizontal-left-10"><label class="H-display-inline-block H-vertical-middle H-theme-background-color1 H-theme-font-color-white H-font-size-12">组员</label></div>
        <span @click="turnPerson(item.tmsName,item.crowdMemberKey,item.tmsTsrId)" class="H-badge H-display-inline-block H-margin-vertical-top-8  H-padding-horizontal-left-10"><i class="iconfont icon-xiaoxi H-font-size-20"></i></span>
      </div>
    </div>
      <div v-show="loading" slot="bottom" class="loading">
        <img src="../../assets/images/loading01.gif">
      </div>
    </load-more>
  </div>
</template>

<script>
  import LoadMore from '../../components/scroll_bottom';
    export default {
        name: '',
        components : {
          LoadMore
        },
        data () {
            return {
              scrollHeight: 0,
              scrollTop: 0,
              containerHeight: 0,
              loading: false,
              allLoaded: false,
              bottomText: '上拉加载更多...',
              bottomStatus: '',
              pageNo: 1,
              totalCount: '',
              endTime:'',
              senderKey:'',
              mobile:'13101783961',
              crowdMemberList:[]
            }
        },
      computed:{
        tel (val) {
          return 'tel:'+ this.mobile
        }
      },
      created () {
        let vm = this;
        vm.renderDom();
//        vm.endTime = setInterval(()=>{
//          vm.renderDom()
//        }, 30000);
      },
      methods:{
        _scroll: function(ev) {
          ev = ev || event;
          this.scrollHeight = this.$refs.innerScroll.scrollHeight;
          this.scrollTop = this.$refs.innerScroll.scrollTop;
          this.containerHeight = this.$refs.innerScroll.offsetHeight;
        },
        isMe (tmsTsrId) {
          if (tmsTsrId != localStorage.tmsTsrId)
            return true;
          else
            return false;
        },
        loadBottom: function() {
          this.loading = true;
          this.pageNo += 1;   // 每次更迭加载的页数
//          console.log(this.pageNo,this.totalCount)
          if (parseInt(this.pageNo) > parseInt(this.totalCount)) {
            // 当allLoaded = true时上拉加载停止
            this.loading = false;
            this.allLoaded = true;
            return;
          }
          let that = this;
          that._ajax('GetCrowdMemeberList',{
            "pageIndex":that.pageNo,
            "pageSize": 10,
            "crowdKey": localStorage.crowdKey,
            "currentLoginMemberKey":localStorage.currentLoginMemberKey
          }, function (data) {
            that.totalCount = data.pageCount;
            that.crowdMemberList = that.crowdMemberList.concat(data.crowdMemberList);
            setTimeout(() => {
//              要使用的后台返回的数据写在setTimeout里面
              that.$nextTick(() => {
                that.loading = false;
            })
          }, 1000)
          })

        },
        handleBottomChange(status) {
          this.bottomStatus = status;
        },
        renderDom () {
          let vm = this;
          vm._ajax('GetCrowdMemeberList',{
//            "pageIndex":1,
//            "pageSize":10,
            "crowdKey": localStorage.crowdKey,
            "currentLoginMemberKey":localStorage.currentLoginMemberKey
          }, (data) => {
            vm.crowdMemberList = data.crowdMemberList;
            vm.totalCount = data.pageCount;
            for (let i in vm.crowdMemberList){
              if (localStorage.tmsTsrId == vm.crowdMemberList[i].tmsTsrId){
                vm.senderKey = vm.crowdMemberList[i].crowdMemberKey
              }
            }
          })
        },
        turnPerson (tsrname,crowdMemberKey,tmsTsrId) {
//          clearInterval(this.endTime);
          if (tmsTsrId == localStorage.tmsTsrId) {
            //提示
            layer.open({
              content: '您不能跟自己聊天！'
              ,skin: 'msg'
              ,time: 1
            });
          }else {
            let vm = this;
            vm.$router.replace('/message_person/'+tsrname+'/'+crowdMemberKey+'/'+ this.senderKey)
          }
        }
      }
    }
</script>

<style scoped>
  a{text-decoration:none}
  .loading{
    text-align: center;
  }
  .message-tip{
    margin-top: 8px;
    position: absolute;
    top: 0;
    left: 35px;
  }
  .message-tip label{
    width: 1.5rem;
    height: 1.5rem;
    text-align: center;
    line-height: 1.2;
    display: inline-block;
    -webkit-border-radius: 50%;
    font-size: 1.2rem;
    color: #FFFFFF;
    background-color: #52ace5;
  }
</style>
