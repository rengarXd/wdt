<template>
  <div>
    <v-header backurl="team_list_head/team_list_body">选择要踢出的成员</v-header>
    <v-search @search-ajax="searchAjax"></v-search>
    <div class="H-padding-horizontal-both-10">
      <div v-for="item in crowdList" v-if="isMe(item.tmsTsrId)" @click="deleteMub(item.crowdMemberKey)" class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-margin-vertical-bottom-2 H-vertical-middle H-touch-active" >
        <input type="radio" name="types"  class="H-radio H-radio-null H-display-block H-vertical-align-middle H-font-size-18 H-theme-font-color4 H-border-radius-circle H-margin-horizontal-both-10">
        <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">
          {{item.tmsName}}
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import Header from '../../components/header'
  import Search from '../../components/search'
  export default {
    name: '',
    components : {
      'v-header': Header,
      'v-search': Search
    },
    data () {
      return {
        crowdList:[]
      }
    },
    mounted () {
      this.renderDom()
    },
    methods:{
      renderDom () {
//        //loading带文字
//        layer.open({
//          type: 2
//          , content: '加载中'
//        });
        this.searchAjax('');
      },
      isMe (tmsTsrId) {
        if (tmsTsrId != localStorage.tmsTsrId)
          return true;
        else
          return false;
      },
      deleteMub (crowdMemberKey) {
        var that = this;
        //询问框
        layer.open({
          content: '您确定要踢出该成员吗？'
          ,btn: ['确定', '不']
          ,yes: function(index){
            layer.close(index);
            //loading带文字
            layer.open({
              type: 2
              , content: '加载中'
            });
            that._ajax('DismissCrowdMember',{
              "companyCode":localStorage.companyCode,
              "crowdCreatePersonCode":localStorage.tmsTsrId,
              "crowdMemberKey":crowdMemberKey
            },function (data) {
              layer.closeAll();
              //提示
              layer.open({
                content: '踢出成功'
                ,skin: 'msg'
                ,time: 1
                ,end:function () {
                  that.searchAjax('')
                }
              });
            })
          }
        });
      },
      searchAjax (whereVal) {
        let that = this;
        that._ajax('GetCrowdMemeberList',{
          "pageIndex":1,
          "pageSize":10,
          "crowdKey":localStorage.crowdKey,
          "currentLoginMemberKey":localStorage.currentLoginMemberKey,
          "where": whereVal
        },function (data) {
          layer.closeAll();
          that.crowdList = data.crowdMemberList;
        })
      }
    }
  }
</script>

<style>

</style>
