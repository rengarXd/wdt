<template>
  <div class="wdt-content">
    <router-link tag="div" to="/team_create"  class="H-padding-20">
      <div class="H-theme-background-color2 login_btn" >创建团队</div>
    </router-link>
    <router-link tag="div" to="/team_join"  class="H-padding-20">
      <div class="H-theme-background-color1 login_btn" >加入团队</div>
    </router-link>
  </div>
</template>

<script>
    export default {
        name: '',
        data () {
            return {}
        }
    }
</script>

<style scoped>
  .wdt-content{
    /*margin-top:10%;*/
    position: relative;
    top: 30px;
    padding: 16%;
    color: #999;
  }
  .login_btn{
    min-width: 120px;
    outline-width:0;
    padding: 10px 20px;
    text-align: center;
    border-radius: 4px;
    color: #ffffff ;
    /*background-color: #03a9f4 !important;*/
  }
</style>
