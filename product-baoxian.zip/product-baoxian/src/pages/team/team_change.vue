<template>
  <div>
    <v-header backurl="team_list_head/team_list_body">移交团队</v-header>
    <v-search @search-ajax="searchAjax"></v-search>
    <div class="H-padding-horizontal-both-10">
      <div v-for="item in crowdList" v-if="isMe(item.tmsTsrId)" @click="changeMub(item.crowdMemberKey)" class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-margin-vertical-bottom-2 H-vertical-middle H-touch-active" >
        <input type="radio" name="types"  class="H-radio H-radio-null H-display-block H-vertical-align-middle H-font-size-18 H-theme-font-color4 H-border-radius-circle H-margin-horizontal-both-10">
        <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">
          {{item.tmsName}}
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import Header from '../../components/header'
  import Search from '../../components/search'
  export default {
    name: '',
    components : {
      'v-header': Header,
      'v-search': Search
    },
    data () {
      return {
        crowdList:[]
      }
    },
    mounted () {
      this.renderDom()
    },
    methods:{
      renderDom () {
        this.searchAjax('');
      },
      isMe (tmsTsrId) {
        if (tmsTsrId != localStorage.tmsTsrId)
          return true;
        else
          return false;
      },
      changeMub (crowdMemberKey) {
        var that = this;
        //询问框
        layer.open({
          content: '您确定要将团队移交给该成员吗？'
          ,btn: ['确定', '不']
          ,yes: function(index){
            layer.close(index);
            //loading带文字
            layer.open({
              type: 2
              , content: '加载中'
            });
            that._ajax('TransferCrowd',{
              "companyCode":localStorage.companyCode,
              "crowdKey":localStorage.crowdKey,
              "tmsTsrId":localStorage.tmsTsrId,
              "transferObjectKey":crowdMemberKey
            },function (data) {
              layer.closeAll();
              localStorage.userCrowdStatus = "";
              //提示
              layer.open({
                content: '移交成功'
                ,skin: 'msg'
                ,time: 1
                ,end:function () {
                  that.$router.replace('/team_list_head/team_list_create')
                }
              });
            })
          }
        });
      },
      searchAjax (whereVal) {
        let that = this;
        that._ajax('GetCrowdMemeberList',{
          "pageIndex":1,
          "pageSize":10,
          "crowdKey":localStorage.crowdKey,
          "currentLoginMemberKey":localStorage.currentLoginMemberKey,
          "where": whereVal
        },function (data) {
          layer.closeAll();
          that.crowdList = data.crowdMemberList;
        })
      }
    }
  }
</script>

<style>

</style>
