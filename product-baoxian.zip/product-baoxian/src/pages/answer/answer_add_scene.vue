<template>
  <div>
    <div v-if="isShow">
      <v-header @click="closeSelf" >添加场景</v-header>
      <div class="H-padding-vertical-bottom-10"></div>
      <div class="H-flexbox-horizontal H-margin-vertical-bottom-10">
        <span class="H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white H-font-size-16">标题：</span><input type="text" v-model="title" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="添加标题...">
      </div>
      <div class="H-flexbox-horizontal H-margin-vertical-bottom-10">
        <textarea v-model="content" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="添加正文..."></textarea>
      </div>
      <div class="H-padding-horizontal-left-10 H-theme-font-color-red">{{errorMessage}}</div>
      <div class="H-padding-25">
        <div class="login_btn" @click="localPref">添加</div>
      </div>
    </div>
  </div>
</template>

<script>
  import Header from '../../components/header'
  export default {
    props: {
      isShow: {
        type: Boolean,
        default: false
      },
      sceneType:{
        type: String,
        default:''
      }
    },
    components : {
      'v-header': Header
    },
    data () {
      return {
        title:'',
        content:'',
        errorMessage:''
      }
    },
    methods:{
      closeSelf () {
        this.$emit('on-close')
      },
      localPref () {
        if(this.title ==''){
          //提示
          layer.open({
            content: '您忘填标题啦！'
            ,skin: 'msg'
            ,time: 2 //2秒后自动关闭
          });
          return;
        }
        //loading带文字
        layer.open({
          type: 2,
          content: '上传中'
        });
        var that = this;
        var a = {
          "Request": {
            "Service": 'AddScene',
            "User": "wdt",
            "SN": "123456",
            "Source": "mobile",
            "Parameters": {
              applyUserId:localStorage.tmsTsrId,
              companyCode:localStorage.companyCode,
              applyUserName:localStorage.tmsTsrName,
              sceneType:that.sceneType,
              content:that.content,
              title:that.title
            }
          }
        };
        var datass = { RequestParam: JSON.stringify(a) };
        $.post(window.baoxianurl, datass, function (data) {
          layer.closeAll();
          if (data.Response.Success == 'False') {
            that.errorMessage = data.Response.Fails[0].Message;
          } else {
            that.errorMessage = '';
            var datas = data.Response.Result;
            that.$emit('showresult',{
              sceneId:datas.sceneId,
              sceneType:that.sceneType,
              content:that.content,
              title:that.title
            })
            that.closeSelf();
            //提示
            layer.open({
              content: '添加成功,请等待审核'
              ,skin: 'msg'
              ,time: 1
            });
          }
        });
      }
    }
  }
</script>

<style scoped>
  .login_btn{
    min-width: 120px;
    outline-width:0;
    padding: 10px 20px;
    text-align: center;
    border-radius: 4px;
    color: #ffffff ;
    background-color: #03a9f4 !important;
  }
</style>
