<template>
  <div id="record_list">
    <header class="H-header b_header_bg">
        <span @click="back" class="H-icon H-position-relative H-display-inline-block H-float-left H-vertical-middle H-theme-font-color-white H-padding-horizontal-left-5 H-padding-horizontal-right-10 H-z-index-100"> <i class="iconfont icon-fanhui H-font-size-22 H-vertical-middle"></i>
        上一级
        </span>
      <div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">{{headName}}</div>
        <span @click="addAnswer" class="H-icon H-position-relative H-display-inline-block H-float-right H-vertical-middle H-theme-font-color-white H-padding-horizontal-right-15 H-z-index-100">
          添加
        </span>
    </header>
    <div style="height: 45px"></div>
    <div class="H-padding-vertical-bottom-10"></div>
    <div v-if="verbalList.length">
      <div v-for="(item,index) in verbalList" class="animated fadeIn H-margin-horizontal-both-10 H-margin-vertical-bottom-10 H-border-radius-3 H-outline-none">
        <div class="H-flexbox-horizontal H-theme-background-color-white ">
          <div class="H-flex-item H-padding-10">
            <strong class="H-font-weight-600  H-font-size-16 H-display-block H-padding-vertical-bottom-5 H-border-vertical-bottom-after"><i class="iconfont icon-wenjuan H-font-weight-500 H-margin-horizontal-right-8 H-theme-font-color-ccc"></i><span class="huashu-text" v-html="item.content"></span></strong>
            <div v-if="item.isAnswer">
              <div  v-for="child in item.feedbackList" @click="turnNewAnswer(child.feedbackId)" class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-margin-vertical-bottom-2 H-vertical-middle " >
                <input type="radio" name="types"  class="H-radio H-radio-null H-display-block H-vertical-align-middle H-font-size-18 H-theme-font-color4 H-border-radius-circle H-margin-horizontal-both-10">
                <div v-html="itemcontent(child.feedbackContent)" class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-5"></div>
              </div>
            </div>
          </div>
        </div>
        <div v-if="!item.addNewverbal" class="H-theme-background-color-white H-border-vertical-bottom-after H-padding-8">
          <button @click="Answer(item.feedbackList.length,index)" class="H-float-right  H-font-size-14 H-outline-none H-theme-background-color-transparent H-padding-3 H-theme-font-color1 H-theme-border-color1 H-theme-border-color1-click H-theme-background-color1-click H-theme-font-color1-click H-border-radius-3">{{item.isanswerTip}}</button>
          <button @click="addFeedback(index,item.verbalId)" class="H-float-right H-margin-horizontal-right-10 H-font-size-14 H-outline-none H-theme-background-color-transparent H-padding-3 H-theme-font-color1 H-theme-border-color1 H-theme-border-color1-click H-theme-background-color1-click H-theme-font-color1-click H-border-radius-3">添加反馈</button>
        </div>
      </div>
    </div>
    <div v-else v-cloak class="no-result custom-color">
      <i style="font-size: 1.8rem;" class="iconfont icon-guanbi"></i>
      <div style="font-size: 0.8rem;">暂无相应话术</div>
    </div>
    <my-dialog :is-show="isShowAdd" @on-close="closeMyself('isShowAdd')">
      <div class="H-padding-vertical-bottom-10 H-font-size-15 H-theme-font-color-ccc">请在下面输入框中添加话术</div>
      <div class="H-flexbox-horizontal H-margin-vertical-bottom-10">
        <textarea v-model="remark" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box  H-outline-none H-padding-12" placeholder="添加你想要的话术..."></textarea>
      </div>
      <div class="H-padding-horizontal-left-10 H-theme-font-color-red">{{errorMessage}}</div>
      <div class="H-padding-10">
        <div class="aui-btn-info login_btn" @click="localPref">添加</div>
      </div>
      <!--发送短信确认-->
    </my-dialog>
  </div>
</template>

<script type="text/ecmascript-6">
  import 'mint-ui/lib/style.css'
  import { MessageBox,Toast } from 'mint-ui';
  import Dialog from '../../components/dialog'
  import Header from '../../components/header'
    export default {
      name: '',
      components : {
        'my-dialog':Dialog,
        'v-header': Header
      },
      data () {
          return {
            isShowAdd: false,
            remark:'',
            errorMessage:'',
            headName:'',
            verbalList:[],//话术列表
            feedbackList:[],
            parent:[],
            type:'',
            index:0,//当前页索引
            isajax:false
          }
      },
      created(){
        this.renderDom()
      },
      methods:{
        itemcontent(str) {
          let a = '';
          a = decodeURI(str);
           return a;
        },
        back () {
          this.parent.pop();
          console.log(JSON.stringify(this.parent));
          if (parseInt(this.index) == 0){
            this.type = 1
            this.$router.replace('/answer_scene');
          }else {
            if (!this.isajax){
              this.type = 2
              this.index = parseInt(this.index) - 1;
              this.isajax = true;
              this.getList(this.index)
            }
          }
        },
        closeMyself (attr) {
          this[attr] = !this[attr]
        },
        renderDom(){
          this.parent.push({
            type:'1',
            parentId:this.$route.params.answerID
          })
          this.getList(this.index)
        },
        getList (index) {
          if (this.parent[index].type == '1'){
            let that = this;
            that.headName = '话术开场白'
            that._ajax('GetSceneVerbal', {
              "companyCode": localStorage.companyCode,
              "sceneId": that.parent[index].parentId
            }, function (data) {
              that.resultFunction(data)
            });
          }else {
            let that = this;
            that.headName = '反馈话术'
            that._ajax('GetFeedbackVerbal', {
              "companyCode": localStorage.companyCode,
              "feedbackId": that.parent[index].parentId
            }, function (data) {
              that.resultFunction(data)
            });
          }
        },
        resultFunction (data) {
          // DOM 更新了
          var that = this;
          let datas = data.verbalList;
          for (let i in datas) {
            if (datas[i].feedbackList.length){
              datas[i].isAnswer = true
              datas[i].isanswerTip = '收起反馈'
            }else {
              datas[i].isAnswer = false
              datas[i].isanswerTip = '暂无反馈'
            }
            datas[i].content = that.itemcontent(datas[i].content)
          }
          that.verbalList = datas;
          that.isajax = false;
        },
        addFeedback (index,verbalId) {
          let vm = this;
          MessageBox.prompt('请输入反馈').then(({ value, action }) => {
            vm._ajax('AddFeedback', {
            "applyUserId":localStorage.tmsTsrId,
            "companyCode":localStorage.companyCode,
            "applyUserName":localStorage.tmsTsrName,
            "verbalId": verbalId,
            "content":value
            }, function (data) {
              for (let i in vm.verbalList){
                if (vm.verbalList[i] == vm.verbalList[index]) {
                  vm.verbalList[i].feedbackList.push({
                    feedbackId:data.feedbackId,
                    feedbackContent:value+ '<span style="color: red">(待审核)</span>'
                  })
                }
              }
              Toast({
                message: '添加成功,请等待审核',
                duration: 1000
              });
            });
          })
        },
        addAnswer () {
          //询问框
            this.isShowAdd = true;
//          this.$router.push('/answer_add_list/'+this.$route.params.type+'/'+this.$route.params.answerID)
        },
        localPref () {
          if (!/^[\w\W]+$/g.test(this.remark)) {
            this.errorMessage = '话术不能为空';
            return
          }
          //loading带文字
          layer.open({
            type: 2,
            content: '上传中'
          });
          var that = this;
          var a = {
            "Request": {
              "Service": 'AddVerbal',
              "User": "wdt",
              "SN": "123456",
              "Source": "mobile",
              "Parameters": {
                "applyUserId":localStorage.tmsTsrId,
                "companyCode":localStorage.companyCode,
                "applyUserName":localStorage.tmsTsrName,
                "addType":that.parent[parseInt(that.index)].type,
                "parentId": that.parent[parseInt(that.index)].parentId,
                "content":that.remark
              }
            }
          };
          var datass = { RequestParam: JSON.stringify(a) };
          $.post(window.baoxianurl, datass, function (data) {
            layer.closeAll();
            if (data.Response.Success == 'False') {
              that.errorMessage = data.Response.Fails[0].Message;
            } else {
              that.errorMessage = '';
              let verbalId = data.Response.Result.verbalId;
              that.verbalList.push({
                "isAnswer" : false,
                "verbalId" : verbalId,
                "content" : that.remark+ '<span style="color: red">(待审核)</span>',
                "addNewverbal":true,
                "feedbackList":[]
              })
              that.isShowAdd = false,
              that.remark = '';
              Toast({
                message: '添加成功,请等待审核',
                duration: 1000
              });
            }
          });
        },
        Answer (isEmpty,index) {
          if (isEmpty){
            this.verbalList[index].isAnswer = !this.verbalList[index].isAnswer;
            if (this.verbalList[index].isAnswer)
              this.verbalList[index].isanswerTip = '收起反馈'
            else
              this.verbalList[index].isanswerTip = '查看反馈'
          }else {
            Toast({
              message: '暂无反馈，您可以添加该反馈',
              duration: 1000
            });
          }
        },
        turnNewAnswer (feedbackId) {
          if (!this.isajax){
            this.parent.push({
              type:2,
              parentId:feedbackId
            })
            this.index = parseInt(this.index) + 1;
            this.getList(parseInt(this.index));
          }
        }
      }
    }
</script>

<style scoped>
  @import "../../assets/css/animate/animate.min.css";
</style>
<style scoped>

  .huashu-text{
    word-wrap : break-word !important;
    margin: 0;
    display: inline;
  }
  .huashu-text p{
    display: inline !important;
  }
  .login_btn{
    min-width: 120px;
    outline-width:0;
    padding: 10px 20px;
    text-align: center;
    border-radius: 4px;
    color: #ffffff ;
    background-color: #03a9f4 !important;
  }
  .H-header{
    position: fixed;
    left:0;
    right: 0;
    z-index: 10000;
  }
  .no-result{
    margin-top: 30px;
    padding: 30px;
    text-align: center;
    background: #f5f5f5;
  }
  .custom-color{
    color: #CCCCCC;
  }
  .square {
    width: 5px;
    max-width: 5px;
    height: 5px;
    background: #10a0d2;
    margin-left: 10px;
    margin-right: 10px;
  }
  .ziti {
    color: #555555;
  }
</style>
