<template>
  <div>
    <v-header :backurl="answerListUrl">添加话术</v-header>
    <div class="H-padding-vertical-bottom-10"></div>
    <div class="H-flexbox-horizontal H-margin-vertical-bottom-10">
      <textarea v-model="remark" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="添加你想要的话术..."></textarea>
    </div>
    <div class="H-padding-horizontal-left-10 H-theme-font-color-red">{{errorMessage}}</div>
    <div class="H-padding-25">
      <div class="aui-btn-info login_btn" @click="localPref">添加</div>
    </div>
  </div>
</template>

<script>
  import Header from '../../components/header'
  export default {
    name: 'team_join_remark',
    components : {
      'v-header': Header
    },
    data () {
      return {
        remark:'',
        errorMessage:''
      }
    },
    computed:{
      answerListUrl() {
        return '/answer_list/'+this.$route.params.type+'/'+this.$route.params.answerID
      }
    },
    watch:{
      remark(val) {
        if (val){
          this.errorMessage = '';
        }
      }
    },
    methods:{
      localPref () {
        if (!/^[\w\W]+$/g.test(this.remark)) {
          this.errorMessage = '话术不能为空';
          return
        }
        //loading带文字
        layer.open({
          type: 2,
          content: '上传中'
        });
        var that = this;
        var a = {
          "Request": {
            "Service": 'AddVerbal',
            "User": "wdt",
            "SN": "123456",
            "Source": "mobile",
            "Parameters": {
              "applyUserId":localStorage.tmsTsrId,
              "companyCode":localStorage.companyCode,
              "applyUserName":localStorage.tmsTsrName,
              "addType":that.$route.params.type,
              "parentId": that.$route.params.answerID,
              "content":that.remark
            }
          }
        };
        var datass = { RequestParam: JSON.stringify(a) };
        $.post(window.baoxianurl, datass, function (data) {
          layer.closeAll();
          if (data.Response.Success == 'False') {
            that.errorMessage = data.Response.Fails[0].Message;

          } else {
            that.errorMessage = '';
            var datas = data.Response.Result;
            //提示
            layer.open({
              content: '添加成功,请等待审核'
              ,skin: 'msg'
              ,time: 1
              ,end:function () {
                that.$router.push(that.answerListUrl)
              }
            });
          }
        });
      }
    }
  }
</script>

<style scoped>
  .login_btn{
    min-width: 120px;
    outline-width:0;
    padding: 10px 20px;
    text-align: center;
    border-radius: 4px;
    color: #ffffff ;
    background-color: #03a9f4 !important;
  }
</style>
