<template>
<div>
  <div v-if="!isAdd">
    <v-header backurl="/">场景</v-header>
    <div v-for="item in sceneList" class="animated fadeIn">
      <div class="H-padding-vertical-bottom-10"></div>
      <div class="H-channel-title H-flexbox-horizontal H-theme-background-color-white H-vertical-middle H-border-vertical-bottom-after">
        <div class="H-channel-line H-theme-background-color-black H-padding-vertical-top-15 H-padding-horizontal-left-3  H-margin-horizontal-left-10"></div>
        <div class="H-channel-text H-theme-font-color-black H-flex-item H-font-size-18 H-theme-font-color-black H-padding-10 H-margin-horizontal-right-10 H-text-show-row-1">{{item.sceneTypeDesc}}</div>
        <!--<router-link :to="answer_add_scene_url(item.sceneType)" tag="button" class="H-button H-margin-horizontal-right-10 H-margin-vertical-bottom-3 H-font-size-15 H-outline-none H-theme-background-color-transparent H-padding-vertical-both-5 H-padding-horizontal-both-10 H-theme-font-color1 H-theme-border-color1 H-theme-border-color1-click H-theme-background-color1-click H-theme-font-color1-click H-border-radius-3">添加场景</router-link>-->
        <button @click="answer_add_scene_url(item.sceneType)" class="H-button H-margin-horizontal-right-10 H-margin-vertical-bottom-3 H-font-size-15 H-outline-none H-theme-background-color-transparent H-padding-vertical-both-5 H-padding-horizontal-both-10 H-theme-font-color1 H-theme-border-color1 H-theme-border-color1-click H-theme-background-color1-click H-theme-font-color1-click H-border-radius-3">添加场景</button>
      </div>
      <div v-for="child in item.sceneDatas" @click="turnList(child.sceneId)" class="H-theme-background-color-white H-margin-vertical-bottom-5">
        <div class="H-flexbox-horizontal H-padding-vertical-both-10 ">
          <span class="H-padding-horizontal-both-10"><i class="iconfont icon-shebeidingwei H-font-size-20 xy_font_color"></i></span>
          <div class="H-flex-item xy_font_color">
            <span v-html="child.title"></span>
          </div>
          <span class="H-icon H-padding-horizontal-right-10 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-18 H-vertical-middle"></i> </span>
        </div>
        <div class="xy_border"></div>
        <div class="H-theme-background-color-white H-theme-font-color-999 H-font-size-13 H-padding-vertical-both-10" style="padding-left: 30px;">
          {{child.content}}
        </div>
      </div>
    </div>
  </div>
  <add-scene :is-show="isAdd" :scene-type="sceneType" @on-close="closeMyself('isAdd')" @showresult="addSceneResult"></add-scene>
</div>
</template>

<script>
  import Header from '../../components/header'
  import AddScene from './answer_add_scene'
  export default {
    name: '',
    components : {
      'v-header': Header,
      AddScene
    },
    data () {
      return {
        isAdd:false,
        sceneType:'',
        sceneList:[]
      }
    },
    created () {
      this.renderDom()
    },
    methods:{
      turnList (sceneId) {
        this.$router.push('/answer_list/'+sceneId);
      },
      answer_add_scene_url (sceneType) {
        this.isAdd = true;
        this.sceneType = sceneType;
//        return '/answer_add_scene/'+sceneType
      },
      addSceneResult(val){
        let newScene = val;
        newScene.title += '<span style="color: red;text-align: right">(待审核)</span> ';
        let arr = this.sceneList;
        for (let i in arr){
          if (newScene.sceneType == arr[i].sceneType){
            delete newScene.sceneType;
            arr[i].sceneDatas.push(newScene);
          }
        }
        console.log(JSON.stringify(arr));
      },
      closeMyself (attr) {
        this[attr] = !this[attr];
      },
      renderDom () {
        let that = this;
        that._ajax('GetScene', {
          "companyCode": localStorage.companyCode
        }, function (data) {
          that.sceneList = data.sceneList;
        });
      }
    }
  }
</script>
<style scoped>
  @import "../../assets/css/animate/animate.min.css";
</style>
<style scoped>
  .iconfont {
    color: #b8b8b8;
  }
  .xy_border {
    border-bottom: 1px solid #f0f0f0;
    margin-left: 20px;
  }
</style>
