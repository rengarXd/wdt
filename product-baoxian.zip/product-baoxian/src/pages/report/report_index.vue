<template>
  <div>
    <header class="H-header b_header_bg">
        <router-link tag="span" to="/"  class="H-icon H-z-index-1000 H-position-relative H-display-inline-block H-float-left H-vertical-middle H-padding-horizontal-both-5"> <i class="iconfont icon-fanhui H-theme-font-color-white H-font-size-20  H-vertical-middle"></i>
        </router-link>
        <div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent"></div>
            <span @click="del_click" class="H-icon H-z-index-1000 H-position-relative H-display-inline-block H-float-right H-vertical-middle H-padding-horizontal-right-5"> <i class="H-iconfont H-icon-dot-more H-theme-font-color-white H-font-size-20  H-vertical-middle"></i>
        </span>
    </header>
    <div style="max-height: 200px">
      <img style="width: 100%" src="../../assets/images/baobiao.png">
    </div>
    <div class="H-padding-vertical-both-10"></div>
    <div onclick="window.location.href= './proposal/report_bar.html';return false" style="border: 1px solid #cbe1f3; border-left: none" class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-both-after H-vertical-middle H-touch-active">
      <span class="H-icon H-center-all H-display-block H-margin-horizontal-left-25 H-theme-font-color-white" ><img  src="../../assets/images/tubiao1.png" width="45px"></span>
      <div style="padding: 35px" class="H-flex-item  H-font-size-20">销售趋势</div>
      <span class="H-icon H-padding-horizontal-right-25 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span>
    </div>
    <div class="H-padding-vertical-both-5 H-theme-background-color-white"></div>
    <div onclick="window.location.href= './proposal/report_col.html';return false" style="border: 1px solid #cbe1f3; border-left: none" class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-both-after H-vertical-middle H-touch-active">
      <span class="H-icon H-center-all H-display-block H-margin-horizontal-left-25 H-theme-font-color-white" ><img  src="../../assets/images/tubiao2.png" width="45px"></span>
      <div style="padding: 35px" class="H-flex-item  H-font-size-20">业绩统计</div>
      <span class="H-icon H-padding-horizontal-right-25 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span>
    </div>
  </div>
</template>

<script>
    export default {
        name: '',
        data () {
            return {}
        },
        methods:{
          del_click () {
            var that = this;
            //询问框
            layer.open({
              content: '您确定要退出登录吗？'
              ,btn: ['退出', '不']
              ,yes: function(index){
                layer.close(index);
                localStorage.clear();
                that.$router.push({ path: '/'});
              }
            });
          }
        }
    }
</script>

<style>

</style>
