<template>
  <div>
    <v-header backurl="/">保障计划书生成</v-header>
    <div class="H-padding-vertical-both-5"></div>
    <div style="color: #5cb85c;" class="H-padding-vertical-both-8 H-theme-background-color-white H-border-vertical-bottom-after" >
        <span class="H-icon H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white"><i class="iconfont icon-xingming H-font-size-18 H-vertical-middle"></i>
            <span class="H-padding-horizontal-left-5 H-font-size-16">被保人信息</span>
        </span>
    </div>
    <div class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-margin-left-10-after H-vertical-middle">
      <div class="H-flex-item H-font-size-16 H-padding-vertical-both-12">
            <span class="H-icon H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white"> <i class="iconfont icon-xingbie H-font-size-18 H-vertical-middle  " style="color:#ea00ff;"></i>
            <span class="H-padding-horizontal-left-5 ">性别</span>
            </span>
      </div>
      <div class="H-padding-horizontal-right-10">
        <input type="radio" name="v" value="1" v-model="sex" checked class="H-radio H-vertical-align-middle H-font-size-18 H-theme-font-color1 H-border-radius-circle">
        <span class="H-margin-horizontal-right-15 H-font-size-16">男</span>
        <input type="radio" name="v" value="2" v-model="sex" class="H-radio H-vertical-align-middle H-font-size-18 H-theme-font-color1 H-border-radius-circle">
        <span class="H-font-size-16">女</span>
      </div>
    </div>
    <div class="H-flexbox-horizontal H-border-vertical-bottom-margin-left-10-after">
        <span class="H-icon H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white">
            <i class="iconfont icon-xingming H-font-size-18 H-vertical-middle " style="color:#ff0000;"></i>
            <span class="H-padding-horizontal-left-5 H-font-size-16">姓名</span>
        </span>
      <input type="text" id="name" v-model="name" class="H-textbox H-text-align-right H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="请输入姓名...">
      <span class="H-theme-background-color-white H-padding-horizontal-right-10"></span>
    </div>
    <div class="H-padding-horizontal-left-15 H-theme-font-color-red" v-html="userErrors.errorText"></div>
    <div class="H-flexbox-horizontal H-border-vertical-bottom-margin-left-10-after">
        <span class="H-icon H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white">
            <i class="iconfont icon-yuyueshijian H-font-size-18 H-vertical-middle" style="color:#60ff00;" ></i>
            <span class="H-padding-horizontal-left-5 H-font-size-16">年龄</span>
        </span>
      <input type="text" id="age" v-model="age" class="H-textbox H-text-align-right H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="请输入年龄...">
      <span class="H-theme-background-color-white H-padding-horizontal-right-10"></span>
    </div>
    <div class="H-padding-horizontal-left-15 H-theme-font-color-red" v-html="ageErrors.errorText"></div>
    <div class="H-padding-vertical-bottom-10"></div>
    <!--选择保险公司-->
    <div @click="company" class="H-text-list  H-vertical-middle  H-flexbox-horizontal H-border-vertical-bottom-after H-theme-background-color-white">
      <span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="iconfont icon-baoxiangongsi  H-font-size-18 H-vertical-middle" style="color:#03a9f4;"></i></span>
      <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">保险公司</div>
      <!--<input type="text"  class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="" readonly="readonly">-->
      <span class="H-padding-horizontal-right-5 H-display-inline H-font-size-15" v-cloak>{{ companyName }}</span>
      <span class="H-icon H-padding-horizontal-right-5 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle" ></i></span>
    </div>
    <!--选择保险公司-->
    <!--选择保险公司列表-->
    <div class="H-padding-10 animated fadeIn" v-if="iscompanylist">
      <div  v-for="item in companyList" @click="companyselect(item.companyName,item.companyCode,item.hotline);" class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle H-touch-active">
        <div v-cloak class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">
          {{  item.companyName }}
        </div>
        <input type="radio" name="company"    class="H-radio H-radio-null H-display-block H-vertical-align-middle H-font-size-18 H-theme-font-color4 H-border-radius-circle H-margin-horizontal-right-10">
      </div>
    </div>
    <!--选择保险公司列表-->
    <!--选择产品-->
    <div @click="productInput" class="H-text-list  H-vertical-middle  H-flexbox-horizontal H-border-vertical-bottom-after H-theme-background-color-white">
      <span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="iconfont icon-chanpin1  H-font-size-18 H-vertical-middle" style="color:#03a9f4;"></i></span>
      <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12  H-text-show-row-1">选择产品</div>
      <!--<input type="text"  class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="" readonly="readonly">-->
      <div class="H-padding-horizontal-right-5  H-font-size-15 H-text-align-right H-text-show-row-1" v-cloak>{{ productName }}</div>
      <span class="H-icon H-padding-horizontal-right-5 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle" ></i></span>
    </div>
    <!--选择产品-->
    <!--选择产品列表-->
    <div  class="H-padding-10 animated fadeIn" v-if="isproductList">
      <div @click="productselectd(item);" v-for="(item,index) in productList" class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle H-touch-active">
        <div v-cloak class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">
          {{  item.productName }}
        </div>
        <input type="radio" name="product"    class="H-radio H-radio-null H-display-block H-vertical-align-middle H-font-size-18 H-theme-font-color4 H-border-radius-circle H-margin-horizontal-right-10">
      </div>
    </div>
    <!--选择产品列表-->
    <!--缴费频率-->
    <div @click="ShowFrequencys" class="H-text-list  H-vertical-middle  H-flexbox-horizontal H-border-vertical-bottom-after H-theme-background-color-white">
      <span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="iconfont icon-jiaofei  H-font-size-18 H-vertical-middle" style="color:#60ff00;"></i></span>
      <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">缴费频率</div>
      <!--<input type="text"  class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="" readonly="readonly">-->
      <span class="H-padding-horizontal-right-5 H-display-inline H-font-size-15" v-cloak>{{ paymentFrequencyName }}</span>
      <span class="H-icon H-padding-horizontal-right-5 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span>
    </div>
    <!--缴费频率-->
    <!--缴费频率列表-->
    <div class="H-padding-10 animated fadeIn" v-if="isShowFrequencys">
      <div  @click="frequencys(item);" v-for="(item,index) in paymentFrequencys" class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle H-touch-active">
        <div v-cloak class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">
          {{  item.paymentFrequencyName }}
        </div>
        <input type="radio" name="product"   class="H-radio H-radio-null H-display-block H-vertical-align-middle H-font-size-18 H-theme-font-color4 H-border-radius-circle H-margin-horizontal-right-10">
      </div>
    </div>
    <!--缴费频率列表-->
    <!--保障计划-->
    <div @click="planClick" class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle H-touch-active">
      <span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="iconfont icon-jihua  H-font-size-18 H-vertical-middle" style="color:#03a9f4;"></i></span>
      <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-text-show-row-1 H-padding-vertical-both-12">保障计划</div>
      <div  class="H-padding-horizontal-right-5 H-font-size-15 H-text-align-right H-text-show-row-1"  v-cloak>{{ planName }}</div>
      <!--<input type="text" readonly="readonly"  :value="planName"  class="H-textbox H-text-align-right H-vertical-align-middle H-vertical-middle H-font-size-16 H-box-sizing-border-box H-border-none H-outline-none H-padding-10">-->
      <span class="H-text-align-right H-icon H-padding-horizontal-right-5 H-display-block"><i v-if="planList.length > 1" class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span>
    </div>
    <div class="H-padding-vertical-bottom-5"></div>
    <!--保障计划-->
    <transition name="fade" tag="div"  v-for="(plan,index) in planCoverages">
      <div style="padding: 5px 5px 0px 5px;"  v-if="plan.display == 'True'" >
        <div class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle">
          <div v-if="plan.basicFlag === 'True'" class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12 H-text-show-row-1">计算主险</div>
          <div v-else class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12 H-text-show-row-1">附加险种</div>
          <span class="H-display-block H-padding-horizontal-right-10  H-font-size-15 H-text-align-right H-text-show-row-1" v-cloak>{{plan.coverageName}}</span>
        </div>
        <!--判断保额/份数类型-->
        <div v-if="plan.sellCoverageType == '20'&& plan.display == 'True'">
          <div class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle">
            <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">份数</div>
            <div class="content H-font-size-15">
              <div id="sub"><i class="icon" @click="reduce">-</i></div>
              <input type="text" name="" :value="value" value="10" id="input-num">
              <div id="plus"><i class="icon" @click="add">+</i></div>
            </div>
          </div>
        </div>
        <div v-else-if="plan.display == 'True'">
          <!--保额为范围时-->
          <div  v-if="plan.faceamountScope.indexOf('-') != -1">
            <div class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle">
              <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">保额</div>
              <input type="text" id="baoeinput" @blur="changebe(beval[index],plan,index)" :value="beval[index]" value="" v-model="beval[index]" class="H-textbox H-text-align-right H-vertical-align-middle H-vertical-middle H-font-size-15 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-10" placeholder="请输入保额">
              <span class="H-icon H-padding-horizontal-right-5 H-display-block"></span>
            </div>
            <div v-if="isBaoe"><span class="H-theme-font-color-red H-font-size-13 H-padding-horizontal-both-10" v-cloak>{{baoeTip}}</span></div>
            <!--<div class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle">-->
            <!--<div class="H-flex-item H-padding-horizontal-both-10 H-font-size-15 H-padding-vertical-both-12">保费</div>-->
            <!--<span class="H-font-size-16 H-theme-font-color-red H-padding-horizontal-both-10 H-padding-vertical-both-12">{{ total }}元</span>-->
            <!--&lt;!&ndash;<div class="H-flex-item H-padding-horizontal-both-10 H-font-size-15 H-padding-vertical-both-12">折后保费：<span class="H-font-size-16 H-theme-font-color-red">{{ baoezhehou() }}元</span></div>&ndash;&gt;-->
            <!--</div>-->
          </div>
          <!--保额可选时-->
          <div v-else>
            <div @click="baoeMyself(plan.faceamountScope,plan.minSalesUnit,index)" class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle">
              <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">保额</div>
              <input type="text" readonly="readonly"  :value="beval[index]" v-model="beval[index]"  class="H-textbox H-text-align-right H-vertical-align-middle H-vertical-middle H-font-size-15 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-10">
              <span  class="H-icon H-padding-horizontal-right-5 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span>
            </div>
            <!--<div class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle">-->
            <!--<div class="H-flex-item H-padding-horizontal-both-10 H-font-size-15 H-padding-vertical-both-12">保费</div>-->
            <!--<span class="H-font-size-16 H-theme-font-color-red H-padding-horizontal-both-10 H-padding-vertical-both-12">{{ total }}元</span>-->
            <!--&lt;!&ndash;<div class="H-flex-item H-padding-horizontal-both-10 H-font-size-15 H-padding-vertical-both-12">折后保费：<span class="H-font-size-16 H-theme-font-color-red">{{ baoezhehou() }}元</span></div>&ndash;&gt;-->
            <!--</div>-->
          </div>
        </div>
        <!--前端显示为空时-->
        <div v-else>
          <!--保额固定时-->
          <!--<div v-else-if="plan.display == 'False'">-->
          <!--<div class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle">-->
          <!--<div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">保额</div>-->
          <!--<span class="H-padding-horizontal-right-10 H-display-inline H-font-size-15">{{ fixBaoe(index) }}</span>-->
          <!--&lt;!&ndash;<input type="text" readonly="readonly"  :value="plan.faceamountScope" v-model="beval[index]"  class="H-textbox H-text-align-right H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-10">&ndash;&gt;-->
          <!--&lt;!&ndash;<span  class="H-icon H-padding-horizontal-right-5 H-display-block"><i class="H-iconfont H-icon-arrow-right H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span>&ndash;&gt;-->
          <!--</div>-->
          <!--</div>-->
        </div>
        <!--前端显示为空时-->
        <!--判断保额/份数类型-->
      </div>
    </transition>
    <div  class="H-text-list H-margin-vertical-top-10 H-vertical-middle H-flexbox-horizontal H-border-vertical-bottom-after H-theme-background-color-white">
      <span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="iconfont icon-baofeicesuan  H-font-size-18 H-vertical-middle" style="color:#5CB85C;"></i></span>
      <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">保费合计：</div>
      <span class="H-padding-horizontal-right-15 H-display-inline H-font-size-18 H-font-weight-500 H-theme-font-color-red">{{ total }}</span>
    </div>
    <!--<div  class="H-text-list  H-vertical-middle  H-flexbox-horizontal H-border-vertical-bottom-after H-theme-background-color-white">-->
    <!--<span class="H-icon H-display-block H-margin-horizontal-left-10"><i class="iconfont icon-baofeicesuan  H-font-size-18 H-vertical-middle"></i></span>-->
    <!--<div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12">首期保费：</div>-->
    <!--<span class="H-padding-horizontal-right-5 H-display-inline H-font-size-15">{{ initalPremium }}</span>-->
    <!--</div>-->
    <div style="padding: 10px 0 0 0;" v-html="errorMessage" class="H-theme-font-color-red H-font-size-13"></div>
    <div class="H-padding-20">
      <div class="aui-btn-info login_btn" @click="localPref">生成计划书</div>
    </div>
    <my-dialog :is-show="isShow"  @on-close="closeMyself('isShow')">
      <!--保费选择-->
      <div class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle">
        <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-15 H-padding-vertical-both-12">请选择以下保额</div>
        <span class="H-icon H-padding-horizontal-right-10 H-display-block"><i class="H-iconfont H-icon-arrow-down H-theme-font-color-ccc H-font-size-14 H-vertical-middle"></i></span>
      </div>
      <div  v-for="item in baoe" @click="changeselectbe(item,index);" class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle H-touch-active">
        <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12"  v-cloak>
          {{  item }}
        </div>
        <input type="radio" name="product"   class="H-radio H-radio-null H-display-block H-vertical-align-middle H-font-size-18 H-theme-font-color4 H-border-radius-circle H-margin-horizontal-right-10">
      </div>
      <!--保费选择-->
    </my-dialog>
    <my-dialog :is-show="isShowPlan" @on-close="closeMyself('isShowPlan')">
      <!--保障计划选择-->
      <div class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle">
        <div class="H-padding-horizontal-both-10 H-font-size-15 H-padding-vertical-both-12">请选择保障计划</div>
      </div>
      <div  v-for="(item,index) in planList" @click="planselect(index);" class="H-text-list H-flexbox-horizontal  H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle H-touch-active">
        <div class="H-flex-item H-padding-horizontal-both-10 H-font-size-16 H-padding-vertical-both-12"  v-cloak>
          {{  item.planName }}
        </div>
        <input type="radio" name="product"   class="H-radio H-radio-null H-display-block H-vertical-align-middle H-font-size-18 H-theme-font-color4 H-border-radius-circle H-margin-horizontal-right-10">
      </div>
      <!--保障计划选择框-->
    </my-dialog>
    <my-dialog :is-show="isShowSMS" @on-close="closeMyself('isShowSMS')">
      <!--发送短信确认-->
      <div class="H-text-list H-flexbox-horizontal H-theme-background-color-white H-border-vertical-bottom-after H-vertical-middle">
        <div class="H-padding-horizontal-both-10 H-font-size-15 H-padding-vertical-both-12">请确认要发送的被保人信息</div>
      </div>
      <div class="H-flexbox-horizontal H-border-vertical-bottom-margin-left-10-after">
            <span class="H-icon H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white">
                <i class="iconfont icon-xingming H-font-size-18 H-vertical-middle " style="color:#ff0000;"></i>
                <span class="H-padding-horizontal-left-5">姓名</span>
            </span>
        <input type="text" v-model="name" style="width: 80%" class="H-textbox H-text-align-right H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="请输入姓名...">
        <span class="H-theme-background-color-white H-padding-horizontal-right-10"></span>
      </div>
      <div class="H-padding-horizontal-left-15 H-theme-font-color-red" v-html="userErrors.errorText"></div>
      <div class="H-flexbox-horizontal H-border-vertical-bottom-margin-left-10-after">
            <span class="H-icon H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white">
                <i class="iconfont icon-dianhua H-font-size-18 H-vertical-middle" style="color:#60ff00;" ></i>
                <span class="H-padding-horizontal-left-5">电话</span>
            </span>
        <input type="text" style="width: 80%"  v-model="mobile" class="H-textbox H-text-align-right H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="请输入电话...">
        <span class="H-theme-background-color-white H-padding-horizontal-right-10"></span>
      </div>
      <div class="H-padding-20">
        <div class="aui-btn-info login_btn" @click="sendSMS" >确认发送</div>
      </div>
      <!--发送短信确认-->
    </my-dialog>
  </div>
</template>

<script>
  import Header from '../../components/header'
  import Dialog from '../../components/dialog'
    export default {
        name: 'Security_program',
        components : {
          'v-header': Header,
          'my-dialog':Dialog
        },
        data () {
            return {
              name: '',
              sex: '1',
              age: '',
              mobile:'',//电话
              ageScope:'1-100',//年龄范围
              companyName: '', /*保限公司*/
              iscompanylist: false, /*保限公司*/
              isproductList: false, /*保险产品*/
              isShow: false,
              isShowPlan: false,
              isShowSMS:false,//是否发送短信
              isShowFrequencys: false, //缴费频率弹出框
              companyCode: '', /*保限公司*/
              companyList: [], /*保限公司*/
              productName: '', /*保险产品*/
              productCode: '', /*保险产品*/
              productList: [], /*保险产品*/
              planName: '', /*保障计划*/
              planCode: '', /*保障计划*/
              planList: [], /*保障计划*/
              planCoverages: [], /*保障计划明细列表*/
              paymentFrequencyName: '', //缴费频率名称
              paymentFrequencyCode: '', //缴费频率代码
              paymentFrequencys: [], //缴费频率
              userPlanCoverages: [], /*用户编辑保障计划明细*/
              baoe: [], //保额选项
              beval: [], //保额值
              index: '', //保额索引
              baoeTip: '',
              isBaoe: false, //是否在保额区间
              value: 1,
              premium: [], //保费子数据
              baofeiData: {}, //保费总数据
              errorMessage: '' //错误信息
            }
        },
      computed: {
        userErrors: function userErrors() {
          var errorText = void 0,
            status = void 0;
          if (!/^[\w\W]+$/g.test(this.name)) {
            status = false;
            errorText = '用户名不能为空';
          } else {
            status = true;
            errorText = '';
          }
          if (!this.userFlag) {
            errorText = '';
            this.userFlag = true;
          }
          return {
            status: status,
            errorText: errorText
          };
        },
        ageErrors: function ageErrors() {
          var min = parseInt(this.ageScope.split("-")[0]);
          var max = parseInt(this.ageScope.split("-")[1]);
          //console.log(min+','+max+','+parseInt(this.age));
          var errorText = void 0,
            status = void 0;
          if (!/^\d{1,3}$/g.test(this.age)) {
            status = false;
            errorText = '年龄填写有误';
          } else if (parseInt(this.age) > max || parseInt(this.age) < min){
            status = false;
            errorText = '该产品年龄范围应在' + this.ageScope+ '之间';
            document.getElementById('age').focus();
          } else {
            status = true;
            errorText = '';
          }
          if (!this.ageFlag) {
            errorText = '';
            this.ageFlag = true;
          }
          return {
            status: status,
            errorText: errorText
          };
        },
        total: function total() {
          console.log(this.premium[0]);
          if (this.premium.length > 0) {
            return this.premium[0] + '元';
          }
//                    if (this.premium.length > 0) {
//                        var num = 0;
//                        for (var i = 0; i < this.premium.length; i++) {
//                            num += parseFloat(this.premium[i].premium);
//                        };
//                        return num + '元';
//                    }
        }
      },
      watch:{
        baofeiData : function (val) {

          if (!this.bxjecal) {
            this.bxjecal = true;
          }else {
            if (val.premiumStd){
              if (this.premium.length > 0) {
                this.premium[0] = val.premiumStd;
                this.premium = this.premium.splice(0,1,val.premiumStd);
              }else {
                this.premium.push(val.premiumStd);
              }
            }
          }
        }
      },
      mounted: function mounted() {
//        this.getRequest().code ? this.code = this.getRequest().code : this.code = '';
//        this.getRequest().name ? this.name = this.getRequest().name : this.name = '';
//        this.getRequest().sex ? this.sex = this.getRequest().sex : this.sex = '1';
//        this.getRequest().age ? this.age = this.getRequest().age : this.age = '';
//        this.getRequest().companyCode ? this.companyCode = this.getRequest().companyCode : this.companyCode = '';
//        this.getRequest().companyName ? this.companyName = this.getRequest().companyName : this.companyName = '';
      },
      methods: {
        //保费为固定时方法
        fixBaoe: function fixBaoe(index) {
          this.beval[index] = this.planCoverages[index].faceamountScope;
          if (this.planCoverages[index].faceamountScope == "") {
            return '-';
          } else {
            return this.planCoverages[index].faceamountScope;
          }
        },
        back: function back() {
          window.history.back();
        },
        //缴费频率选择列表展示
        ShowFrequencys: function ShowFrequencys() {
          var that = this;
          if (that.productCode) {
            that.isShowFrequencys = !that.isShowFrequencys;
          } else {
            //alert('请先选择产品');
            //提示
            layer.open({
              content: '请先选择产品'
              ,skin: 'msg'
              ,time: 2 //2秒后自动关闭
            });
          }
        },
        //缴费频率选中方法
        frequencys: function frequencys(item) {
          var that = this;
          that.iscompanylist = false, /*保限公司*/
            that.isproductList = false, /*保险产品*/
            that.baoe = []; //保额选项
          that.beval = []; //保额值
          that.index = ''; //保额索引
          that.value = 1;
          that.premium = []; //保费数据
          that.baofeiData = {};
          that.paymentFrequencyName = item.paymentFrequencyName;
          that.paymentFrequencyCode = item.paymentFrequencyCode;
          //关闭选择框
          setTimeout(function () {
            that.isShowFrequencys = false;
          }, 100);
        },
        //保费计算
        baofei: function baofei(index) {
          var that = this;
          //console.log(that.beval[index] + '====' + that.isBaoe);
          //console.log(JSON.stringify(that.baofeiData));
          if (that.beval[index] && !that.isBaoe) {
            var planCoverages = new Array();
            for (var i in that.planCoverages) {
              if (that.beval[i]){
                planCoverages.push({
                  "coverageCode": that.planCoverages[i].coverageCode,
                  "policyTerm": that.planCoverages[i].policyTerm,
                  "premiumTerm": that.planCoverages[i].premiumTerm,
                  "amount": that.beval[i],
                  "premium": ""
                });
              }else {
                planCoverages.push({
                  "coverageCode": that.planCoverages[i].coverageCode,
                  "policyTerm": that.planCoverages[i].policyTerm,
                  "premiumTerm": that.planCoverages[i].premiumTerm,
                  "amount": that.planCoverages[i].faceamountScope,
                  "premium": ""
                });
              }
            }
            layer.open({
              type: 2,
              content: '保费计算中'
            });
            that.__ajax('PremiumCalculate', {
              "companyCode": that.companyCode,
              "insuredAge": that.age,
              "insuredSex": that.sex,
              "paymentFrequencyCode": that.paymentFrequencyCode,
              "planCode": that.planCode,
              "planCoverages": planCoverages
            }, function (data) {
              //console.log(JSON.stringify(data));
              that.baofeiData = data;
              setTimeout(function () {
                layer.closeAll();
              }, 300);
//                            //总保费数据存储
//                            if (that.baofeiData && that.baofeiData.length > 0) {
//                                for (var i = 0; i < that.baofeiData.length; i++) {
//                                    if (that.baofeiData[i].companyCode != data.companyCode) {
//                                        that.baofeiData.push(data);
//                                    }
//                                }
//                            } else {
//                                that.baofeiData = data;
//                            }
//                            //单个保费
//                            if (that.premium.length > 0) {
//                                for (var i = 0; i < that.premium.length; i++) {
//                                    if (that.premium[i].coverageCode !== data.planCoverages[0].coverageCode) {
//                                        that.premium = that.premium.concat(data.planCoverages);
//                                    } else if (that.premium[i].coverageCode == data.planCoverages[0].coverageCode && that.premium[i].amount != data.planCoverages[0].amount) {
//                                        that.premium = data.planCoverages;
//                                    } else {
//                                        return;
//                                    }
//                                }
//                            } else {
//                                that.premium = data.planCoverages;
//                            }
              //console.log(JSON.stringify(that.premium));
            });
          }
        },
        //保额选择
        baoeMyself: function baoeMyself(faceamountScope, minSalesUnit, index) {
          var that = this;
          that.index = index;
          faceamountScope.indexOf(",") > 0 ? that.baoe = faceamountScope.split(",") : that.baoe = [faceamountScope];

          that.isShow = !that.isShow;
        },
        //输入保额失去焦点事件
        changebe: function changebe(value, plan, index) {
          var that = this;
          if (that.planCoverages.length > 0) {
            if (value < parseFloat(plan.faceamountScope.split("-")[0]) || value > parseFloat(plan.faceamountScope.split("-")[1])) {
              that.baoeTip = '请输入范围在' + plan.faceamountScope + '保额';
              that.isBaoe = true;
              document.getElementById('baoeinput').focus();
            } else {
              that.beval[that.index] = value;
              that.isBaoe = false;
              that.baofei(index);
            }
          }
        },
        //保额选择确定
        changeselectbe: function changeselectbe(item, index) {
          var that = this;
          that.beval[that.index] = item;
          that.baofei(index);
          //关闭选择框
          setTimeout(function () {
            that.isShow = false;
          }, 100);
        },
        add: function add() {
          this.value = parseInt(this.value) + 1;
        },
        reduce: function reduce() {
          this.value <= 0 ? this.value = 0 : this.value = this.value = parseInt(this.value) - 1;
        },
        closeMyself: function closeMyself(attr) {
          this[attr] = !this[attr];
        },
        //选择保险公司
        company: function company() {
          var that = this;

          if (that.getRequest().companyCode){
            return;
          }
          if (!that.userErrors.status || !that.ageErrors.status) {
            if (!that.userErrors.errorText || !that.ageErrors.errorText) {
              //alert('姓名或年龄填写有误');
              //提示
              layer.open({
                content: '姓名或年龄填写有误'
                ,skin: 'msg'
                ,time: 2 //2秒后自动关闭
              });
              return;
            }
          }
          that.iscompanylist = !that.iscompanylist;
          if (that.iscompanylist) {
            layer.open({
              type: 2,
              content: '加载中'
            });
            that.__ajax('GetInsuranceCompanyList', {
              "companyCode": that.companyCode
            }, function (data) {
              that.companyList = data.companyList;
              layer.closeAll();
              //console.log(JSON.stringify(data));
            });
          }else {
            that.iscompanylist = false;
          }
        },
        //保险公司选中方法
        companyselect: function companyselect(companyName, companyCode,hotline) {
          var that = this;
          that.ageScope = '1-100';//年龄范围
          that.productName = ''; /*保险产品*/
          that.productCode = ''; /*保险产品*/
          that.productList = []; /*保险产品*/
          that.planName = ''; /*保障计划*/
          that.planCode = ''; /*保障计划*/
          that.planList = []; /*保障计划*/
          that.planCoverages = []; /*保障计划*/
          that.paymentFrequencyName = ''; //缴费频率名称
          that.paymentFrequencyCode = ''; //缴费频率代码
          that.paymentFrequencys = []; //缴费频率
          that.baoe = []; //保额选项
          that.beval = []; //保额值
          that.index = ''; //保额索引
          that.value = 1;
          that.premium = []; //保费数据
          that.baofeiData = {};
          that.isproductList = false;
          that.companyName = companyName;
          that.companyCode = companyCode;
          that.hotline = hotline;
          //关闭选择框
          setTimeout(function () {
            that.iscompanylist = false;
          }, 100);
        },
        //产品显示列表
        productInput: function productInput() {
          var that = this;
          if (that.companyCode) {
            layer.open({
              type: 2,
              content: '加载中'
            });
            that.__ajax('GetInsuranceProductList', {
              "companyCode": that.companyCode,
              "productCode": ""
            }, function (data) {
              that.isproductList = !that.isproductList;
              that.productList = data.productList;
              layer.closeAll();
            });
          } else {
            //alert('请先选择保险公司');
            //提示
            layer.open({
              content: '请先选择保险公司'
              ,skin: 'msg'
              ,time: 2 //2秒后自动关闭
            });
          }
        },
        //产品选中方法
        productselectd: function productselectd(item) {
          var that = this;
          that.ageScope = '1-100';//年龄范围
          that.planName = ''; /*保障计划*/
          that.planCode = ''; /*保障计划*/
          that.planList = []; /*保障计划*/
          that.planCoverages = []; /*保障计划*/
          that.baoe = []; //保额选项
          that.beval = []; //保额值
          that.index = ''; //保额索引
          that.value = 1;
          that.premium = []; //保费数据
          that.baofeiData = {};
          that.iscompanylist = false;
          that.productName = item.productName;
          that.productCode = item.productCode;
          that.paymentFrequencys = item.paymentFrequencys;
          if (item.paymentFrequencys.length){
            that.paymentFrequencyName = item.paymentFrequencys[0].paymentFrequencyName;
            that.paymentFrequencyCode = item.paymentFrequencys[0].paymentFrequencyCode;
          }else {
            return;
          }
          that.__ajax('GetInsuranceProductDetail', {
            "companyCode": that.companyCode,
            "productCode": that.productCode
          }, function (data) {
            if (data) {
              that.planList = data.productList;
              that.planName = data.productList[0].planName;
              that.planCode = data.productList[0].planCode;
              that.planCoverages = data.productList[0].planCoverages;
              that.ageScope = data.productList[0].ageScope;//年龄范围
            }
            //that.companyList = data.Response.Result.companyList;
          });
          //关闭选择框
          setTimeout(function () {
            that.isproductList = false;
          }, 100);
        },
        //保障计划下拉显示
        planClick: function planClick() {
          if (this.planList.length > 1) {
            //console.log(JSON.stringify(this.planList));
            this.isShowPlan = !this.isShowPlan;
          }
        },
        //保障计划确定
        planselect: function planselect(index) {
          var that = this;
          //                    that.planName='';/*保障计划*/
          //                    that.planCode='';/*保障计划*/
          //                    that.planList=[];/*保障计划*/
          //                    that.planCoverages=[];/*保障计划*/
          that.baoe = []; //保额选项
          that.beval = []; //保额值
          that.index = ''; //保额索引
          that.value = 1;
          that.premium = []; //保费数据
          that.baofeiData = {};
          that.planName = that.planList[index].planName;
          that.planCode = that.planList[index].planCode;
          that.planCoverages = that.planList[index].planCoverages;
          that.ageScope = that.planList[index].ageScope;//年龄范围
          //关闭选择框
          setTimeout(function () {
            that.isShowPlan = false;
          }, 100);
        },
        __ajax: function(Service, request, callback) {
          var that = this;
          var a = {
            "Request": {
              "Service": Service,
              "User": "wdt",
              "SN": "123456",
              "Source": "mobile",
              "Parameters": request
            }
          };
          var datass = { RequestParam: JSON.stringify(a) };
          $.post(window.baoxianurl, datass, function (data) {
            if (data.Response.Success == 'False') {
              that.errorMessage = data.Response.Fails[0].Message + '请重新选择';
              layer.closeAll();
            } else {
              that.errorMessage = '';
              if (typeof callback == 'function') {
                callback(data.Response.Result);
              }
            }
          });
        },
        //获取url链接数据
        getRequest: function getRequest() {
          var url = location.search; //获取url中"?"符后的字串
          var theRequest = new Object();
          if (url.indexOf("?") != -1) {
            var str = url.substr(1);
            var strs = str.split("&");
            for (var i = 0; i < strs.length; i++) {
              theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
            }
          }
          return theRequest;
        },
        //发送短信
        sendSMS:function sendSMS(){
          console.log(this.name,this.mobile)
        },
        //生成计划书
        localPref: function localPref() {
          if (window.localStorage) {
            //console.log(this.total +'===='+this.premium);
            if(this.name ==''){
              //提示
              layer.open({
                content: '您忘填姓名啦！'
                ,skin: 'msg'
                ,time: 2 //2秒后自动关闭
              });
              return;
            }
            if (this.age == ''){
              //提示
              layer.open({
                content: '您忘填年龄啦！'
                ,skin: 'msg'
                ,time: 2 //2秒后自动关闭
              });
              return;
            }
            if (this.companyName == ''){
              //提示
              layer.open({
                content: '您忘选公司啦！'
                ,skin: 'msg'
                ,time: 2 //2秒后自动关闭
              });
              return;
            }
            if (this.productName == ''){
              //提示
              layer.open({
                content: '您忘选产品啦！'
                ,skin: 'msg'
                ,time: 2 //2秒后自动关闭
              });
              return;
            }
            if (this.paymentFrequencyName == ''){
              //提示
              layer.open({
                content: '您忘选缴费频率啦！'
                ,skin: 'msg'
                ,time: 2 //2秒后自动关闭
              });
              return;
            }
            if (this.paymentFrequencyName == ''){
              //提示
              layer.open({
                content: '您忘选缴费频率啦！'
                ,skin: 'msg'
                ,time: 2 //2秒后自动关闭
              });
              return;
            }
            if (!this.total){
              //提示
              layer.open({
                content: '保费未计算！'
                ,skin: 'msg'
                ,time: 2 //2秒后自动关闭
              });
              return;
            }
            //记录本地存储偏好值
//                        localStorage.setItem("name", this.name);
//                        localStorage.setItem("sex", this.sex);
//                        localStorage.setItem("age", this.age);
//                        localStorage.setItem("ageScope",this.ageScope);
//                        localStorage.setItem("companyName", this.companyName);
//                        localStorage.setItem("hotline",this.hotline);
//                        localStorage.setItem("productName", this.productName);
//                        localStorage.setItem("productCode", this.productCode);
//                        localStorage.setItem("companyCode", this.companyCode);
//                        localStorage.setItem("paymentFrequencyName", this.paymentFrequencyName);
//                        localStorage.setItem("paymentFrequencyCode", this.paymentFrequencyCode);
////                        localStorage.setItem("planList", JSON.stringify(this.planList));
//                        localStorage.setItem("planName",this.planName);
//                        localStorage.setItem("planCode",this.planCode);
//                        localStorage.setItem("baofeiData", JSON.stringify(this.baofeiData));

            var datas  = new Object();
            datas.CustomerCode = this.code;
            datas.customerName = this.name;
            datas.insuredSex = this.sex;
            datas.insuredAge = this.age;
            datas.companyName = this.companyName;
            datas.companyCode = this.companyCode;
            datas.companyHotline = this.hotline;
            datas.paymentFrequencyName = this.paymentFrequencyName;
            datas.paymentFrequencyCode = this.paymentFrequencyCode;
            datas.productName = this.productName;
            datas.productCode = this.productCode;
            datas.planName = this.planName;
            datas.planCode = this.planCode;
            datas.tmsTsrId = localStorage.tmsTsrId;
            datas.Source = 'WDT';
//                        datas.tmsTaskKey = localStorage.tmsTaskKey;
            datas.tmsBranchCode = localStorage.tmsBranchCode;

            var resultObj = this.extendObj(datas,this.baofeiData);

            this.__ajax("GenProposal",resultObj,function (data) {
//                            console.log(data);
              window.location.href = data.proposalUrl;
//                            if (localStorage.tmsTsrId){
//                                window.history.back()
//                            }else {
//                                window.location.href = data.proposalUrl;
//                            }
            })
          } else {
            alert('This browser does NOT support localStorage');
          }
        },
        cloneObj : function(oldObj) {
          var that = this;

          if (that.isObject(oldObj) == false) {
            return oldObj;
          }
          var newObj = new Object();
          for (var i in oldObj) {
            newObj[i] = that.cloneObj(oldObj[i]);
          }
          return newObj;
        },
        isObject : function(obj) {
          var that = this;
          return (that.isTargetType(obj, "object") && obj != null && obj != undefined);
        },
        isTargetType : function(obj, typeString) {
          return typeof obj === typeString;
        },
        extendObj : function() {
          var that = this;

          var args = arguments;
          if (args.length < 2) {
            return;
          }
          var temp = that.cloneObj(args[0]);
          //调用复制对象方法
          for (var n = 1; n < args.length; n++) {
            for (var i in args[n]) {
              temp[i] = args[n][i];
            }
          }
          return temp;
        }
      }
    }
</script>
<style scoped>
  @import "../../assets/css/animate/animate.min.css";
</style>
<style scoped>
  a{text-decoration: none;}
  .content{
    display: -webkit-flex;
    display: flex;
    /*flex-direction:row;*/
    align-items:center;
    flex-wrap: nowrap;
    height: 2rem;
    background: #EEEEEE;
    font-size: 20px;
    margin-right: 1rem;
  }
  .content input{
    border:none;
    border:1px solid #eee;
    /*border-radius: 5px;*/
    text-align: center;
    width: 2.3rem;
    height: 2rem;
  }
  #plus{display:block; text-align:center;padding:6px;}
  #sub{
    display:block;
    text-align: center;
    padding: 6px;
  }

  .aui-btn-info {
    color: #ffffff ;
    background-color: #03a9f4 !important;
  }
  .login_btn{
    min-width: 120px;
    outline-width:0;
    padding: 10px 20px;
    text-align: center;
    border-radius: 4px;
  }
</style>
