<template>
  <div >
    <header class="header_bg  aui-bar aui-bar-nav">
      <a  class="aui-pull-left"> <i v-cloak class="iconfont icon-fanhui"></i>
      </a>
      <div class="aui-title">我的客户</div>
      </a>
    </header>
  </div>
</template>

<script>
    export default {
        name: '',
        data () {
            return {}
        }
    }
</script>

<style scoped src="../../assets/css/aui.css">

</style>
