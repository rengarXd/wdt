<template>
  <div>
    <header class="H-header b_header_bg">
      <router-link tag="span" :to="{path: '/default/'+messageType}"  class="H-icon H-z-index-1000 H-position-relative H-display-inline-block H-float-left H-vertical-middle H-padding-horizontal-both-5"> <i class="iconfont icon-fanhui H-theme-font-color-white H-font-size-20  H-vertical-middle"></i>
      </router-link>
      <div class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent" v-cloak>{{title}}</div>
    </header>
    <div v-cloak class="H-flexbox-horizontal H-theme-background-color-white H-clear-both">
      <div  class="H-padding-vertical-both-10 H-box-sizing-border-box">
        <!--<img src="../../../image/logo.png" alt="" title="" class="H-display-block H-margin-horizontal-right-10" style="width: 70px; height: 70px;">-->
        <span v-cloak v-if="messageType == '1'" class="complaints_letter"><i class="iconfont icon-wf_touxiang"></i></span>
        <span v-cloak  v-else class="complaints_letter"><i class="iconfont icon-touxiang1"></i></span>
        <!--<div v-cloak v-else class="circle_bg H-display-block H-margin-horizontal-left-10">-->
        <!--<span class="first_letter"><i class="iconfont icon-kehu1"></i></span>-->
        <!--</div>-->
      </div>
      <div  class="H-flex-item H-position-relative H-box-sizing-border-box" style="padding: 15px 10px 0 10px;">
        <span class="H-float-left H-font-size-16 H-theme-font-color-666"  style="line-height: 2.7">{{tmsName}}</span>
        <div class="comitNum H-theme-font-color-999"><span class="H-float-right H-padding-horizontal-right-10" v-cloak>{{uploadTime}}</span><span class="H-padding-horizontal-right-10">{{totalReplyCount}}{{messageType == '1'? '评论':'回答'}}</span></div>
      </div>
    </div>
    <div class="title-text" v-cloak>{{content}}</div>

    <div v-if="isFirst" v-cloak class="no-result H-border-both-after H-theme-font-color-ccc addh_active" @click="firstComit">
      <div style="font-size: 1.6rem;" v-cloak><i style="font-size: 2.4rem;padding-right: 20px" class="iconfont icon-iconfontpinglun"></i>点此发表第一条{{commentName}}</div>
    </div>
      <!-- 上拉加载更多 -->
      <load-more :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" :bottomPullText='bottomText' :auto-fill="false"  @bottom-status-change="handleBottomChange"  ref="loadmore">

      <div  v-for="(item,index) in commentList"  class="H-flexbox-horizontal H-theme-background-color-white H-border-vertical-bottom-after H-clear-both">
        <div class="H-padding-vertical-both-8">
          <!--<img id="face" src="../../../image/logo.png" srcs="" alt="" title="" class="imgCache H-display-block H-margin-horizontal-left-10 H-border-radius-circle" style="width: 30px; height: 30px;">-->
          <span v-cloak v-if="messageType == '1'" class="complaints_letter"><i class="iconfont icon-shangchuantouxiang"></i></span>
          <div v-cloak v-else class="circle_bg H-display-block H-margin-horizontal-left-10">
            <span class="first_letter"><i class="iconfont icon-kehu1"></i></span>
          </div>
        </div>
        <div class="H-flex-item H-margin-vertical-top-15 H-margin-vertical-bottom-10 H-margin-horizontal-both-10">
          <div class="H-theme-font-color-999 H-flexbox-horizontal H-text-horizontal-left H-box-sizing-border-box">
            <span class="H-display-block H-flex-item H-text-align-left H-font-size-14 H-theme-font-color1"  v-cloak>{{item.tmsName}}</span>
            <span class="H-display-block H-flex-item H-text-align-right H-theme-font-color-ccc H-font-size-13"  v-cloak>{{index + 1}}楼</span>
          </div>
          <div  v-cloak class="H-theme-font-color-999 H-margin-vertical-top-5">
            <span class=" H-font-size-15">{{item.content}}</span>
            <div  v-cloak v-for="info in item.replyList" class="H-padding-5 H-margin-vertical-both-5 H-border-radius-3 H-theme-background-color-eee H-font-size-13">
              <span class="H-theme-font-color1" >{{info.tmsName}}：</span>{{info.content}}
            </div>
            <div v-if="item.isAnswer" v-cloak class="H-padding-5 H-box-sizing-border-box H-flexbox-horizontal H-theme-background-color-f4f4f4">
              <div class="H-flexbox-horizontal H-flex-item H-border-both-after" style="border-radius: 5px;">
                <span class="H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white"><img src="../../assets/images/common_map.png" width="20" style="margin-top:4px" /></span>
                <input v-model="comment" type="text" @focus="iscommentList = false" @blur="iscommentList = true" class="H-textbox  H-vertical-align-middle H-vertical-middle H-font-size-13 H-flex-item H-box-sizing-border-box H-border-none H-outline-none" placeholder="输入想要回复的内容" >
                <span @click="clearComment(index)" class="H-icon H-vertical-middle H-padding-horizontal-right-10 H-theme-background-color-white"><img src="../../assets/images/common_del.png" width="20" style="margin-top: 4px" /></span>
              </div>
              <div class="H-padding-horizontal-both-10  H-center-all H-font-size-14" @click="comitSubmit(item.key)">回复</div>
            </div>
          </div>
          <div  v-cloak class="H-font-size-10 H-theme-font-color-999 H-text-show-row-1 H-padding-vertical-top-3 H-font-size-13" >
            {{item.uploadTime}}<span class="H-theme-font-color1 H-float-right" @click="answer(index)">{{ item.answerCtlName }}</span>
          </div>
        </div>
      </div>
        <div v-show="loading" slot="bottom" class="loading">
          <img src="../../assets/images/loading01.gif">
        </div>
      </load-more>

    <div v-if="isposBottom" style="height: 59px"></div>
    <div v-if="iscommentList" style="position: fixed;bottom: 0;left: 0;background-color: #FFFFFF;" class="H-padding-8  H-flexbox-horizontal">
      <div class="H-flexbox-horizontal H-flex-item" style="border-radius: 5px;border: 1px solid rgb(224, 224, 224)">
        <span class="H-vertical-middle H-padding-horizontal-left-10 H-theme-background-color-white H-font-size-16"><img src="../../assets/images/common_map.png" width="20" style="margin-top:4px" /></span>
        <input @blur="isposBottom = true" @focus="isposBottom = false" v-model="contentInput" type="text" class="H-textbox H-width-100-percent H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-5" placeholder="输入想要的信息" id="search_main">
        <span @click="contentInput = ''" class="H-icon H-vertical-middle H-padding-horizontal-right-10 H-theme-background-color-white"><img src="../../assets/images/common_del.png" width="20" style="margin-top: 4px" /></span>
      </div>
      <div :style="{ color: activeColor }" class="H-padding-horizontal-both-10 H-margin-horizontal-right-10 H-center-all" @click="commentSubmit" v-cloak>{{commentName}}</div>
    </div>
  </div>
</template>

<script>
  import LoadMore from '../../components/scroll_bottom';
  export default {
      name: 'detail',
      components : {
        LoadMore
      },
      data () {
          return {
            activeColor:'#999',
            scrollHeight: 0,
            scrollTop: 0,
            containerHeight: 0,
            loading: false,
            allLoaded: false,
            bottomText: '上拉加载更多...',
            bottomStatus: '',
            pageNo: 1,
            totalCount: '',

            title:'',
            messageKey:'',
            tmsName:'',//用户名
            content:'',//内容
            uploadTime:'',//时间
            commentList:[],//评论列表
            comment:'',//评论内容
            messageType:'',//类型
            totalReplyCount:'',//总回复数
            contentInput:'',
            iscommentList:false,
            commentName:'',//输入框名称
            isposBottom : true,
            isFirst:false
          }
      },
      watch:{
        contentInput(val) {
          if (val){
            this.activeColor = '#03aafe'
          }else {
            this.activeColor = '#999'
          }
        }
      },
      mounted: function mounted() {
        this.renderDom();
      },
      methods: {
        back:function back() {
          if (this.getRequest().type == '1'){
            return window.location.href = './default.html?active='+0+'&currentView=child1';
          }else {
            return window.location.href = './default.html?active='+1+'&currentView=child2';
          }
        },
        _scroll: function(ev) {
          ev = ev || event;
          this.scrollHeight = this.$refs.innerScroll.scrollHeight;
          this.scrollTop = this.$refs.innerScroll.scrollTop;
          this.containerHeight = this.$refs.innerScroll.offsetHeight;
        },
        loadBottom: function() {
          this.loading = true;
          this.pageNo += 1;   // 每次更迭加载的页数
          if (parseInt(this.pageNo) > parseInt(this.totalCount)) {
            // 当allLoaded = true时上拉加载停止
            this.loading = false;
            this.allLoaded = true;
            return;
          }

          let that = this;

          that.common_ajax('GetMessageDetailComment',{
            "pageIndex":that.pageNo,
            "pageSize": 10,
            "messageKey":that.messageKey
          }, function (data) {
            that.totalCount = data.pageCount;
            let datas = data.commentList;
            for (let i in datas) {
              datas[i].isAnswer = false;
              datas[i].answerCtlName = '回复';
            }
            that.commentList = that.commentList.concat(datas);
            setTimeout(() => {
//              要使用的后台返回的数据写在setTimeout里面
              that.$nextTick(() => {
                that.loading = false;
              })
            }, 1000)
          })

        },
        handleBottomChange(status) {
          this.bottomStatus = status;
        },
        answer:function answer(i){
          this.commentList[i].isAnswer = !this.commentList[i].isAnswer;
          this.comment = '';
          for (var a in this.commentList){
            if (a !=i && this.commentList[a].isAnswer){
              this.commentList[a].isAnswer = false;
              this.commentList[a].answerCtlName = '回复'
            }
          }
          if(this.commentList[i].isAnswer){
            this.commentList[i].answerCtlName = '关闭'
          }else {
            this.commentList[i].answerCtlName = '回复'
          }
        },
        clearComment:function clearComment(i) {
          var that = this;

          if (that.comment !=''){
            that.comment = '';
          }else {
            that.answer(i)
          }
        },
        firstComit:function firstComit() {
          this.iscommentList = !this.iscommentList;
          this.isFirst = !this.isFirst;
          $("#search_main").focus();
        },
        comitSubmit:function comitSubmit(commentKey) {
          if (!/^[\w\W]{1,100}$/.test(this.comment)){
            //信息框
            layer.open({
              content: '输入内容不在范围之内'
              ,btn: '我知道了'
            });
            return;
          };
          var that = this;
          that.common_ajax('AddComment',{
            "messageKey":that.messageKey,
            "content" : that.comment,
            "commentKey":commentKey,
            "tmsTsrId":localStorage.tmsTsrId,
            "companyCode" : localStorage.companyCode,
            "tmsName":localStorage.tmsTsrName
          },function (data) {
            that.getDetail();
            that.comment = '';
            setTimeout(function () {
              //提示
              layer.open({
                content: '回复成功！'
                ,skin: 'msg'
                ,time: 1 //1秒后自动关闭
              });
            },100);
          })
        },
        commentSubmit:function comment() {
          if (!/^[\w\W]{1,100}$/.test(this.contentInput)){
            //信息框
            layer.open({
              content: '输入内容不在范围之内'
              ,btn: '我知道了'
            });
            return;
          };
          var that = this;
//          //loading带文字
//          layer.open({
//            type: 2
//            , content: '上传中'
//          });
          that.common_ajax('AddComment',{
            "messageKey":that.messageKey,
            "content" : that.contentInput,
            "tmsTsrId":localStorage.tmsTsrId,
            "companyCode" : localStorage.companyCode,
            "tmsName":localStorage.tmsTsrName
          },function (data) {
            that.getDetail();
            that.contentInput = '';
            setTimeout(function () {
              //提示
              layer.open({
                content: '评论成功！'
                ,skin: 'msg'
                ,time: 1 //2秒后自动关闭
              });
            },100);
          })
        },
        renderDom : function renderDom() {
//          console.log(this.$route.params);
          this.messageType = this.$route.params.messageType;
          this.messageKey = this.$route.params.messageKey;
          if (this.messageType == '1'){
            this.title = '吐槽详情';
            this.commentName = '评论'
          }else {
            this.title = '问答详情'
            this.commentName = '回答'
          }
          this.getDetail();
        },
        getComment:function Comment(callback) {
          var that = this;
          that.common_ajax('GetMessageDetailComment',{
            "pageIndex":1,
            "pageSize": 10,
            "messageKey":that.messageKey
          },function (data) {
            if (data.commentList.length){
              that.iscommentList = true;
              that.isFirst = false
            }else {
              that.isFirst = true
              that.iscommentList = false
            }
            var datas = data.commentList;
            that.totalCount = data.pageCount;
            for (var i in datas){
              datas[i].isAnswer = false;
              datas[i].answerCtlName = '回复';
            }
            that.commentList = datas;
            if (typeof callback == 'function')
              callback();
          })
        },
        getDetail:function getDetail() {
          var that = this;
          //loading带文字
//          layer.open({
//            type: 2
//            , content: '加载中'
//          });
          that.common_ajax('GetMessageDetail',{
            "messageKey":that.messageKey
          },function (data) {
            that.tmsName = data.tmsName ? data.tmsName:'匿名';
            that.content = data.content;
            that.uploadTime = data.uploadTime;
            that.totalReplyCount = data.totalReplyCount;
            that.messageType = data.messageType;
            that.getComment();
          })
        },
        common_ajax: function common_ajax(Service, request, callback) {
          var that = this;
          var a = {
            "Request": {
              "Service": Service,
              "User": "wdt",
              "SN": "123456",
              "Source": "mobile",
              "Parameters": request
            }
          };
          var datass = {RequestParam: JSON.stringify(a)};
          $.post(window.baoxianurl, datass, function (data) {
            if (data.Response.Success == 'False') {
              layer.closeAll();
            } else {
              if (typeof callback == 'function') {
                callback(data.Response.Result);
              }
            }
          });
        }
      }
    }
</script>

<style scoped>
  .loading{
      text-align: center;
  }
  .circle_bg{
    width:3rem;
    height: 3rem;
    background: #ccc;
    border-radius: 100%;
  }
  .first_letter {
    color: #fff;
    font-size: 3rem;
  }
  .title-text{
    background-color: white;
    margin: 0 0 10px 0;
    padding: 0 10px 15px 55px;
    word-break:break-all;
    color: #000;
    font-size: 2rem;
    font-weight: normal;
    font-weight: 500;
  }
  .no-result{
    margin-top: 30px;
    padding: 30px;
    text-align: center;
    background: #f5f5f5;
    border:1px solid;
  }
  .addh_active{
    margin: 15px 50px 30px 50px;
    padding: 15px;
    text-align: center;
  }
  .addh_active:active {
    background: #f5f5f5;
  }
  .comitNum{
    margin: 0;
    float: right;
    line-height: 3.2rem;
    padding-left: 40px;
    color: #999;
    font-size: 1.3rem;
  }
  .complaints_letter{
    display: block;
    color: #000 !important;
    margin-left: 0.5rem;
    line-height: normal;
    text-align: center;
    font-size: 40px;
  }
</style>
