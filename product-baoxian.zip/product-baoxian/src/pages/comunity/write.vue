<template>
  <div>
    <header class="H-header b_header_bg">
        <router-link tag="span" :to="{path: '/default/'+messageType}"  class="H-icon H-z-index-1000 H-position-relative H-display-inline-block H-float-left H-vertical-middle H-padding-horizontal-both-5"> <i class="iconfont icon-fanhui H-theme-font-color-white H-font-size-20  H-vertical-middle"></i>
        </router-link>
      <div v-cloak class="H-header-title H-center-all H-font-size-18 H-text-show-row-1 H-theme-font-color-white H-position-absolute H-width-100-percent">{{title}}</div>
    </header>
    <!--<div class="H-channel-title H-flexbox-horizontal H-theme-background-color-white H-vertical-middle H-border-vertical-bottom-after">-->
    <!--<div class="H-channel-line H-theme-background-color6 H-padding-vertical-top-15 H-padding-horizontal-left-3  H-margin-horizontal-left-10"></div>-->
    <!--<div class="H-channel-text H-theme-font-color-black H-flex-item H-font-size-18 H-theme-font-color-black H-padding-10 H-margin-horizontal-right-10 H-text-show-row-1">{{title}}</div>-->
    <!--</div>-->
    <div class="H-padding-vertical-bottom-10"></div>
    <div class="H-flexbox-horizontal H-margin-vertical-bottom-10 H-border-vertical-both-after">
      <textarea v-model="content" class="H-textbox H-vertical-align-middle H-vertical-middle H-font-size-16 H-flex-item H-box-sizing-border-box H-border-none H-outline-none H-padding-12" placeholder="总得写点什么..."></textarea>
    </div>
    <div class="H-padding-20">
      <div class="aui-btn-info login_btn" @click="sub">提&nbsp;交</div>
    </div>
  </div>
</template>

<script>
    export default {
        name: 'write',
        data () {
            return {
              title:'',
              content:'',
              tmsName:'',
              messageType:'',
              isComit:false
            }
        },
        mounted:function () {
          this.renderDom();
        },
        methods: {
          renderDom : function renderDom() {
            this.$route.params.type == '1' ? this.renderA() : this.renderB();
          },
          renderA : function renderA() {
            this.title = '发布吐槽'
            this.messageType = '1'
          },
          renderB : function renderB() {
            this.title = '填写问答'
            this.messageType = '2'
          },
          sub: function sub() {
            if (!/^[\w\W]{1,500}$/.test(this.content)){
              //信息框
              layer.open({
                content: '输入内容不在范围之内'
                ,btn: '我知道了'
              });
              return;
            };
            var that = this;
            if (!that.isajax) {
              that.isajax = true;
              that.common_ajax('AddOrDeleteMessage', {
                "operation":'add',
                "companyCode": localStorage.companyCode ? localStorage.companyCode : '',
                "tmsTsrId": localStorage.tmsTsrId ? localStorage.tmsTsrId : '',
                "messageType":that.messageType,
                "content": that.content,
                "tmsName": localStorage.tmsTsrName ? localStorage.tmsTsrName : ''
              }, function (data) {
                //提示
                layer.open({
                  content: '发送成功！'
                  ,skin: 'msg'
                  ,time: 1 //2秒后自动关闭
                  ,end :function () {
                    that.$router.push({path: '/default/'+that.messageType});
                  }
                });
              });
            }
          },
          getRequest: function getRequest() {
            var url = location.search; //获取url中"?"符后的字串
            var theRequest = new Object();
            if (url.indexOf("?") != -1) {
              var str = url.substr(1);
              var strs = str.split("&");
              for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
              }
            }
            return theRequest;
          },
          common_ajax: function common_ajax(Service, request, callback) {
            var that = this;
            var a = {
              "Request": {
                "Service": Service,
                "User": "wdt",
                "SN": "123456",
                "Source": "mobile",
                "Parameters": request
              }
            };
            var datass = {RequestParam: JSON.stringify(a)};
            $.post(window.baoxianurl, datass, function (data) {
              if (data.Response.Success == 'False') {
                //提示
                layer.open({
                  content: '发送失败'
                  ,skin: 'msg'
                  ,time: 1 //2秒后自动关闭
                  ,end :function () {
                    that.isajax = false;
                  }
                });
              } else {
                if (typeof callback == 'function') {
                  callback(data.Response.Result);
                }
              }
            });
          }
        }
    }
</script>

<style scoped>
  .login_btn{
    min-width: 120px;
    outline-width:0;
    padding: 10px 20px;
    text-align: center;
    border-radius: 4px;
    color: #ffffff !important;
    background-color: #03a9f4 !important;
  }
</style>
