<template>
  <div>
    <v-header backurl="/">交流中心</v-header>
    <div class="H-flexbox-horizontal  H-margin-vertical-bottom-10" style="position: fixed;top:45px;z-index: 1000">
      <div v-cloak  v-for="(tab,index) in tabs" @click="toggle(index ,tab.view)" class="H-flex-item H-theme-background-color-white H-center-all H-padding-vertical-both-10 H-theme-border-color-white H-font-size-16"  style="border-width: 0 0 2px  0" :class="{'com-active':active == index}" >{{tab.type}}</div>
      <!--<div class="H-flex-item H-center-all H-padding-vertical-both-10 H-theme-border-color-white H-touch-active H-font-size-16" style="border-width: 0 0 2px  0">问答</div>-->
    </div>
    <div style="height: 46px"></div>
    <div v-if="currentView == 'child1'">
      <mt-loadmore :top-method="onRefresh" :topDistance="parseInt(30)" topPullText="" topLoadingText="加载中.." ref="loadmore"  @top-status-change="handleTopChange">
      <div v-if="complaints.length">
        <div v-cloak v-for="item in complaints" @click="turnDetail(item.messageKey,item.messageType)" class="H-flexbox-horizontal H-theme-background-color-white H-margin-vertical-bottom-5 H-clear-both">
          <div class="H-padding-vertical-both-10">
            <!--<img src="../../../image/logo.png" alt="" title="" class="H-display-block H-margin-horizontal-right-10" style="width: 70px; height: 70px;">-->
            <div class="H-margin-horizontal-left-10">
              <span class="complaints_letter"><i class="iconfont icon-shangchuantouxiang"></i></span>
            </div>
          </div>
          <div class="H-flex-item  H-position-relative H-box-sizing-border-box" style="height: 90px;padding: 10px 20px 10px 10px;">
            <strong style="word-break:break-all;" class=" H-font-weight-normal font-weight-500 H-font-size-16 H-display-block H-text-show-row-2 H-theme-font-color-666" v-cloak>{{item.content}}</strong>
            <p class="H-font-size-14 H-theme-font-color-999 H-position-absolute H-z-index-10 H-margin-0" style="bottom: 10px; left: 10px; right: 10px;">
              <span class="H-float-left" v-cloak>{{item.tmsName}}</span>
              <span class="H-float-right H-padding-horizontal-right-10" v-cloak>
                  <i class="iconfont icon-xiaoxi H-font-size-16 H-display-inline-block"></i>
                  <span class="H-padding-horizontal-right-15">{{item.replyCount}}</span>
                  <i class="iconfont icon-riqi H-font-size-16 H-display-inline-block"></i>
                  {{item.uploadTime}}
              </span>
            </p>
          </div>
        </div>
      </div>
      <div v-else v-cloak class="no-result H-theme-font-color-ccc">
        <i style="font-size: 2.4rem;" class="iconfont icon-yuyueshijian"></i>
        <div style="font-size: 1.6rem;">{{nullname1}}</div>
      </div>
        <div slot="top" class="mint-loadmore-top H-center-all">
          <span v-show="topStatus === 'loading'"><img src="../../assets/images/loading01.gif"></span>
        </div>
      </mt-loadmore>
      <router-link to="/write/1">
        <div class="circle_input H-display-block">
          <span class="input-letter"><i class="iconfont icon-jihuashu H-font-size-30"></i></span>
          <span class="H-font-size-13 H-display-block H-theme-font-color-white">发布</span>
        </div>
      </router-link>
    </div>
    <div v-else>
      <mt-loadmore :top-method="onRefresh" topPullText="" topLoadingText="加载中.." ref="loadmore"  @top-status-change="handleTopChange">
      <div v-if="answerList.length">
        <div v-cloak v-for="item in answerList" @click="turnDetail(item.messageKey,item.messageType)" class="H-flexbox-horizontal H-theme-background-color-white H-margin-vertical-bottom-10 H-clear-both">
          <div class="H-padding-vertical-both-10 H-box-sizing-border-box">
            <!--<img src="../../../image/logo.png" alt="" title="" class="H-display-block H-margin-horizontal-right-10" style="width: 70px; height: 70px;">-->
            <div class="circle_bg H-display-block H-margin-horizontal-left-10">
              <span class="first_letter"><i class="iconfont icon-kehu1"></i></span>
            </div>
          </div>
          <div class="H-flex-item  H-position-relative H-box-sizing-border-box" style="height: 110px;padding: 10px 20px 10px 10px;">
            <div class="H-z-index-10 H-margin-0"><span class="H-float-left H-font-size-14 H-theme-font-color-666" >{{item.tmsName}}</span></div>
            <div style="top:32px;" class="H-position-absolute H-font-size-13 H-theme-font-color-999 H-padding-horizontal-right-10">
              <!--<span class="H-padding-horizontal-right-10">{{item.replyCount}}回答</span>{{item.uploadTime}}-->
                  <span class="H-float-right H-padding-horizontal-right-10" v-cloak>
                      <i class="iconfont icon-xiaoxi H-font-size-16 H-display-inline-block"></i>
                      <span class="H-padding-horizontal-right-15">{{item.replyCount}}</span>
                      <i class="iconfont icon-riqi H-font-size-16 H-display-inline-block"></i>
                      {{item.uploadTime}}
                  </span>
            </div>
            <strong style="top: 58px;" class="H-font-weight-normal font-weight-500 H-font-size-16 H-position-absolute H-text-show-row-2 ">{{item.content}}</strong>
          </div>
        </div>
      </div>
      <div v-else v-cloak class="no-result H-theme-font-color-ccc">
        <i style="font-size: 2.4rem;" class="iconfont icon-yuyueshijian"></i>
        <div style="font-size: 1.6rem;">{{nullname2}}</div>
      </div>
        <div slot="top" class="mint-loadmore-top H-center-all">
          <span v-show="topStatus === 'loading'"><img src="../../assets/images/loading01.gif"></span>
        </div>
      </mt-loadmore>
      <router-link to="/write/2">
        <div class="circle_input H-display-block">
          <span class="input-letter"><i class="iconfont icon-jihuashu H-font-size-30"></i></span>
          <span class="H-font-size-13 H-display-block H-theme-font-color-white">提问</span>
        </div>
      </router-link>
    </div>
  </div>
</template>

<script>
//    import Scroll from '../../components/scroll'
    import Header from '../../components/header'
    import { Loadmore } from 'mint-ui';

    export default {
        name: 'default',
        components : {
          'mt-loadmore': Loadmore,
          'v-header': Header
        },
        data () {
            return {
              counter: 1, //当前页
              topStatus:'',
              listdata: [], // 下拉更新数据存放数组
              scrollData: {
                noFlag: false //暂无更多数据显示
              },
              nullname1:'',//
              nullname2:'',
              answerList: [], //问答列表
              complaints: [], //吐槽列表
              currentView: 'child1',
              tabs: [{
                type: '吐槽',
                view: 'child1'
              }, {
                type: '问答',
                view: 'child2'
              }],
              active: 0
            }
        },
      computed:{
        offset (){
         return Number(60);
        }
      },
      mounted: function mounted() {
        console.log(this.$route.params);
        this.getFirstDetail();
      },
      methods: {
        onRefresh() {
          this.getLists();
//          done(); // call done
        },
        handleTopChange(status) {
          this.topStatus = status;
        },
        onInfinite(done) {
//            if (this.answerList.length > 10){
//
//            }
//          this.counter++;
//          let end = this.pageEnd = this.num * this.counter;
//          let i = this.pageStart = this.pageEnd - this.num;

          let more = this.$el.querySelector('.load-more')
          more.style.display = 'none'; //隐藏加载条
//              //走完数据调用方法
          this.scrollData.noFlag = true;
//          var that = this;
//          that.common_ajax('GetMessageList', {
//              "messageType": parseInt(that.active) + 1
//            }, function (data) {
//              var datas = data.productList;
//              for (var i = 0; i < datas.length; i++) {
//                if (datas[i].tmsName == '') {
//                  datas[i].tmsName = '匿名';
//                }
//                if (datas[i].messageType == '2') {
//                  that.answerList = datas;
//                } else {
//                  that.complaints = datas;
//                }
//              }
//              more.style.display = 'none'; //隐藏加载条
//              });
//          for(i; i < end; i++) {
//            if(i >= 30) {
//              more.style.display = 'none'; //隐藏加载条
//              //走完数据调用方法
//              this.scrollData.noFlag = true;
//
//              break;
//            } else {
////              this.listdata.push({
////                date: "2017-06-1"+i,
////                portfolio: "1.5195"+i,
////                drop: i+"+.00 %" ,
////                state: 2
////              })
//
//              var that = this;
//              that.common_ajax('GetMessageList', {
//                "messageType": parseInt(that.active) + 1
//              }, function (data) {
//                var datas = data.productList;
//                for (var i = 0; i < datas.length; i++) {
//                  if (datas[i].tmsName == '') {
//                    datas[i].tmsName = '匿名';
//                  }
//                  if (datas[i].messageType == '2') {
//                    that.answerList = datas;
//                  } else {
//                    that.complaints = datas;
//                  }
//                }
//                setTimeout(function () {
//                  layer.closeAll();
//                }, 300);
//              });
//              more.style.display = 'none'; //隐藏加载条
//            }
          done();
        },
        toggle: function toggle(i, v) {
          this.active = i;
          this.currentView = v;
          this.getLists();
        },
        getnextList : function() {
          var that = this;
          that.common_ajax('GetMessageList', {
            "messageType": parseInt(that.active) + 1
          }, function (data) {
            var datas = data.productList;
            that.nullname1 = '快来发布吐槽吧'
            that.nullname2 = '快来发布问答吧'
            for (var i = 0; i < datas.length; i++) {
              if (datas[i].tmsName == '') {
                datas[i].tmsName = '匿名';
              }
              if (datas[i].messageType == '2') {
                that.answerList = datas;
              } else {
                that.complaints = datas;
              }
            }
            setTimeout(function () {
              layer.closeAll();
            }, 300);
          });
        },
        getLists : function() {
          var that = this;
          that.common_ajax('GetMessageList', {
            "messageType": parseInt(that.active) + 1
          }, function (data) {
            var datas = data.productList;
            that.nullname1 = '快来发布吐槽吧'
            that.nullname2 = '快来发布问答吧'
            for (var i = 0; i < datas.length; i++) {
              if (datas[i].tmsName == '') {
                datas[i].tmsName = '匿名';
              }
              if (datas[i].messageType == '2') {
                that.answerList = datas;
              } else {
                that.complaints = datas;
              }
            }
            setTimeout(function () {
              that.$refs.loadmore.onTopLoaded();
              layer.closeAll();
            }, 300);
          });
        },
        turnDetail: function turnDetail(messageKey, messageType) {
          this.$router.push({ name: 'detail', params: { messageType: messageType,messageKey:messageKey }})
        },
        turnWrite: function turnWrite(name) {
          return window.location.href= './write.html?type=2';
        },
        getFirstDetail: function getFirstDetail() {
          if (this.$route.params.type == '1'){
            this.active = 0;
            this.currentView = 'child1';
          }else {
            this.active = 1;
            this.currentView = 'child2';
          }
          var that = this;
          //loading带文字
          layer.open({
            type: 2,
            content: '加载中'
          });
          that.common_ajax('GetMessageList', {
//                    "companyCode": localStorage.companyCode ? localStorage.companyCode : '',
//                    "tmsTsrId": localStorage.tmsTsrId ? localStorage.tmsTsrId : '',
            "messageType": parseInt(that.active) + 1
          }, function (data) {
            var datas = data.productList;
            for (var i = 0; i < datas.length; i++) {
              if (datas[i].tmsName == '') {
                datas[i].tmsName = '匿名';
              }
              if (datas[i].messageType == '2') {
                that.answerList.push(datas[i]);
              } else {
                that.complaints.push(datas[i]);
              }
            }
            setTimeout(function () {
              layer.closeAll();
            }, 300);
            //                    console.log(that.$data);
          });
        },
        common_ajax: function common_ajax(Service, request, callback) {
          var that = this;
          var a = {
            "Request": {
              "Service": Service,
              "User": "wdt",
              "SN": "123456",
              "Source": "mobile",
              "Parameters": request
            }
          };
          var datass = { RequestParam: JSON.stringify(a) };
          $.post(window.baoxianurl, datass, function (data) {
            if (data.Response.Success == 'False') {
              layer.closeAll();
            } else {
              if (typeof callback == 'function') {
                callback(data.Response.Result);
              }
            }
          });
        }
      }
    }
</script>

<style lang="css" scoped>
  .circle_bg{
    width:3rem;
    height: 3rem;
    background: #ccc;
    border-radius: 100%;
  }
  .first_letter {
    color: #fff;
    font-size: 3.2rem;
  }
  .complaints_letter{
    display: block;
    color: #000 !important;
    margin: 0 auto;
    line-height: normal;
    text-align: center;
    font-size: 32px;
  }
  .circle_input{
    width: 4em;
    height: 4em;
    background: #63aeff;
    border-radius: 50%;
    position: fixed;
    top: 450px;
    z-index: 10000;
    right: 20px;
    text-align: center
  }
  .input-letter{
    display: block;
    color: #fff;
    line-height: normal;
    text-align: center;
  }
  .com-active{
    border: 1px solid #63aeff;
    color: #63aeff;
    z-index: 10000;
  }
  .com-active:active{
  /*color: #fff;*/
  border: 1px solid #63aeff;
  }
  .no-result{
    margin-top: 30px;
    padding: 30px;
    text-align: center;
    background: #f5f5f5;
  }
</style>
