<template>
  <router-view></router-view>
</template>
<script>
  import './assets/css/Hui.css'
  import './assets/css/Hui.ttf'
  import './assets/common'
  import './assets/tools/jquery.min'
  export default { name: 'app'}
</script>
<style lang="css">
  @import "assets/css/iconfont/iconfont.css";
</style>
<style>
  .b_header_bg {
    background: -webkit-gradient(linear, left top, left bottom, from(#000), to(#999));
  }
  [v-cloak] {
    display: none;
  }
  ::-webkit-input-placeholder { /* WebKit browsers */
    color: #CCCCCC;
  }
</style>

