import Vue from 'vue'
import Router from 'vue-router'

const Main = resolve => require(['@/pages/Main'], resolve)
const Default = resolve => require(['@/pages/comunity/default'], resolve)
const Security_program = resolve => require(['@/pages/proposal/Security_program'], resolve)
const Write = resolve => require(['@/pages/comunity/write'], resolve)
const Detail = resolve => require(['@/pages/comunity/detail'], resolve)
const Login = resolve => require(['@/pages/login'], resolve)
const Report_index = resolve => require(['@/pages/report/report_index'], resolve)
const Team_list_head = resolve => require(['@/pages/team/team_list_head'], resolve)
const Team_list_create = resolve => require(['@/pages/team/team_list_create'], resolve)
const Team_list_body = resolve => require(['@/pages/team/team_list_body'], resolve)
const Team_work = resolve => require(['@/pages/team/team_work'], resolve)
const Team_create = resolve => require(['@/pages/team/team_create'], resolve)
const Team_join = resolve => require(['@/pages/team/team_join'], resolve)
const Team_join_remark = resolve => require(['@/pages/team/team_join_remark'], resolve)
const Message_main = resolve => require(['@/pages/team/message/message_main'], resolve)
const Message_person = resolve => require(['@/pages/team/message/message_person'], resolve)
const Team_delete = resolve => require(['@/pages/team/team_delete'], resolve)
const Team_change = resolve => require(['@/pages/team/team_change'], resolve)
const Answer_list = resolve => require(['@/pages/answer/answer_list'], resolve)
const Answer_scene = resolve => require(['@/pages/answer/answer_scene'], resolve)
// const Answer_add_scene = resolve => require(['@/pages/answer/answer_add_scene'], resolve)
// const Answer_add_list = resolve => require(['@/pages/answer/answer_add_list'], resolve)

// import Main from '@/pages/Main'
// import Security_program from '@/pages/proposal/Security_program'
// import Default from  '@/pages/comunity/default'
// import Write from  '@/pages/comunity/write'
// import Detail from '@/pages/comunity/detail'
// import Login from '@/pages/login'
// import Report_index from '@/pages/report/report_index'
// import Team_list_head from '@/pages/team/team_list_head'
// import Team_list_create from '@/pages/team/team_list_create'
// import Team_list_body from '@/pages/team/team_list_body'
// import Team_work from '@/pages/team/team_work'
// import Team_create from '@/pages/team/team_create'
// import Team_join from '@/pages/team/team_join'
// import Team_join_remark from '@/pages/team/team_join_remark'
// import Message_main from '@/pages/team/message/message_main'
// import Team_delete from '@/pages/team/team_delete'
// import Message_person from '@/pages/team/message/message_person'
// import Team_change from '@/pages/team/team_change'
// import Answer_list from '@/pages/answer/answer_list'
// import Answer_scene from '@/pages/answer/answer_scene'
// import Answer_add_scene from '@/pages/answer/answer_add_scene'
// import Answer_add_list from '@/pages/answer/answer_add_list'

Vue.use(Router)

export default new Router({
  // mode: 'history',
  routes: [
    { path: '/',
      name: 'main',
      component: Main
    },
    {
      path: '/default/:type',
      name: 'default',
      component: Default
    },
    {
      path: '/detail/:messageType/:messageKey',
      name: 'detail',
      component: Detail
    },
    {
      path: '/write/:type',
      name: 'Write',
      component: Write
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/report_index',
      name: 'report_index',
      component: Report_index
    },
    {
      path: '/Security_program',
      name: 'Security_program',
      component: Security_program
    },
    {
      path: '/team_list_head/',
      name: 'team_list_head',
      component: Team_list_head,
      children:[
        { path: 'team_list_body', component: Team_list_body },
        { path: 'team_list_create', component: Team_list_create },

      ]
    },
    {
      path: '/team_work',
      name: 'team_work',
      component: Team_work
    },
    {
      path: '/team_create',
      name: 'team_create',
      component: Team_create
    },
    {
      path: '/team_join',
      name: 'team_join',
      component: Team_join
    },
    {
      path: '/team_change',
      name: 'team_change',
      component: Team_change
    },
    { path:'/message_main',name:'message_main', component: Message_main},
    { path: '/team_join_remark/:crowdKey', component: Team_join_remark },
    { path:'/team_delete',name:'team_delete',component: Team_delete},
    { path: '/message_person/:tmsname/:receiveKey/:senderKey',name:'message_person', component: Message_person },
    {
      path: '/answer_list/:answerID',
      name:'answer_list',
      component:Answer_list
    },
    {
      path:'/answer_scene',
      name:'answer_scene',
      component:Answer_scene
    },
    // {
    //   path:'/answer_add_scene/:sceneType',
    //   name:'answer_add_scene',
    //   component:Answer_add_scene
    // },
    // {
    //   path:'/answer_add_list/:type/:answerID',
    //   name:'answer_add_list',
    //   component:Answer_add_list
    // }
  ]
})
