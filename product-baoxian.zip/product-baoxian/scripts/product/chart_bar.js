/**
 * Created by aaa on 2017/5/24.
 */
new Vue({
    el:'#app',
    data:{
        productList:[],
        dataList:[],
        datas:{},
        inpstart:'',
        inpend:'',
        isActive:false
    },
    mounted :function () {
        this.timeSelect();
        this.inpstart = parseInt($.nowDate().substr(0,4))-1 + $.nowDate().substring(4,7)
        this.search()
    },
    methods:{
        getRequest:function () {
            var url = location.search; //获取url中"?"符后的字串
            var theRequest = new Object();
            if (url.indexOf("?") != -1) {
                var str = url.substr(1);
                strs = str.split("&");
                for(var i = 0; i < strs.length; i ++) {
                    theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
                }
            }
            return theRequest;
        },
        search:function () {
            var that = this;
            let companycode = that.getRequest().companyCode ? that.getRequest().companyCode:localStorage.companyCode;
            let tmsBranchCode = that.getRequest().tmsBranchCode ? that.getRequest().tmsBranchCode:localStorage.tmsBranchCode;
            console.log(companycode+'==='+tmsBranchCode);
            var a ={
                "Request":{
                    "Service":"ProductSaleTrend",
                    "User":"wdt",
                    "SN":"123456",
                    "Source":"mobile",
                    "Parameters":{
                        "companyCode": companycode,
                        "tmsBranchCode": tmsBranchCode,
                        "startDate": that.inpstart + '-01',
                        "endDate": that.inpend + '-01'
                    }
                }
            }
            var datass = {RequestParam:JSON.stringify(a)}
            $.post("http://192.168.0.104:8096/ClientService/WdtService.ashx",datass ,function (data) {
                console.log(data.Response.Result);
                that.productList = data.Response.Result.productList;
                that.dataList = productList[0].dataList;
                that.chartDataFuncion('销售件数')
//                        var gettpl = document.getElementById('demo').innerHTML;
//                        laytpl(gettpl).render(productList, function(html){
//                            document.getElementById('view').innerHTML = html;
//                            chartDataFuncion('销售件数');
//                            var $avtive=$(".chooser-list").find("li")
//                            $avtive.click(function(){
//                                $(this).addClass('action').siblings().removeClass('action');
//                                chartDataFuncion($(this).html())
//                            });
//                        });
            });
        },
        selectProduct:function (i) {
            var ii = $(obj).val();
            this.dataList = this.productList[ii].dataList;
        },
        chartDataFuncion:function (name) {
            var that = this;
            if(name == '销售件数'){
                var saleCount = new Array();
                that.datas.name = '销售件数';
                that.datas.type = 'bar'
                for (let i in that.dataList){
                    saleCount.push(parseFloat(dataList[i].saleCount))
                }
                that.datas.data = saleCount;
            }else {
                var saleAmount = new Array();
                that.datas.name = '销售金额';
                that.datas.type = 'bar'
                for (let i in that.dataList){
                    saleAmount.push(parseFloat(dataList[i].saleAmount))
                }
                that.datas.data = saleAmount;
            }
            that.Echarts()
        },
        timeSelect:function () {
            //将时间转换成标准时间
            var parserDate = function (date) {
                var t = Date.parse(date);
                if (!isNaN(t)) {
                    return new Date(Date.parse(date.replace(/-/g, "/")));
                } else {
                    return new Date();
                }
            };

            function AddYear(times) {
                // 先获取当前时间
                var curDate = (times).getTime();
                // 将半年的时间单位换算成毫秒
                var oneYear = 365 * 24 * 3600 * 1000;
                var pastResult = curDate + oneYear;  // 一年前的时间（毫秒单位）
                var date = new Date();
                //console.log(now.getTime());
                if(pastResult >= date.getTime()){
                    var y = date.getFullYear();
                    var m = date.getMonth() + 1;
                    m = m < 10 ? '0' + m : m;
                    var d = date.getDate();
                    d = d < 10 ? ('0' + d) : d;
                    return y + '-' + m + '-' + d;
                }else {
                    // 日期函数，定义起点为半年前
                    var pastDate = new Date(pastResult),
                        pastYear = pastDate.getFullYear(),
                        pastMonth = pastDate.getMonth() + 1,
                        pastDay = pastDate.getDate();
                    return pastYear + '-' + pastMonth + '-' + pastDay;
                }
            }
            function MinYear(times) {
                // 先获取当前时间
                var curDate = (times).getTime();
                // 将半年的时间单位换算成毫秒
                var oneYear = 365 * 24 * 3600 * 1000;
                var pastResult = curDate - oneYear;  // 一年前的时间（毫秒单位）
                // 日期函数，定义起点为半年前
                var pastDate = new Date(pastResult),
                    pastYear = pastDate.getFullYear(),
                    pastMonth = pastDate.getMonth() + 1,
                    pastDay = pastDate.getDate();
                return pastYear + '-' + pastMonth + '-' + pastDay;
            }
            var start = {
                format: 'YYYY-MM',
                minDate: '2011-01-01', //设定最小日期为当前日期
                isinitVal:false,
                festival:true,
                ishmsVal:false,
                maxDate: $.nowDate({DD:0}), //最大日期
                choosefun: function(elem, val, date){
                    //console.log(AddYear(parserDate(val+'-01 00:00:00')));
                    end.minDate = val+'-01'; //开始日选好后，重置结束日的最小日期
                    end.maxDate = AddYear(parserDate(val+'-01 00:00:00'));
                    endDates();
                }
            };
            var end = {
                format: 'YYYY-MM',
                minDate: '2011-01-01', //设定最小日期为当前日期
                isinitVal:true,
                festival:true,
//            hmsSetVal:{hh:00,mm:12,ss:00},
                maxDate: $.nowDate(), //最大日期
                choosefun: function(elem, val, date){
                    //console.log(this.maxDate);
                    start.minDate = MinYear(parserDate(val+'-01 00:00:00'))
                    start.maxDate = val+'-01'; //将结束日的初始值设定为开始日的最大日期
                }
            };
            //这里是日期联动的关键
            function endDates() {
                //将结束日期的事件改成 false 即可
                end.trigger = false;
                $("#inpend").jeDate(end);
            }
            $('#inpstart').jeDate(start);
            $('#inpend').jeDate(end);
        },
        Echarts:function () {
            console.log(JSON.stringify(datas));
            var that = this;
            // 路径配置
            require.config({
                paths: {
                    echarts: 'http://echarts.baidu.com/build/dist'
                }
            });

            // 使用
            require(
                [
                    'echarts',
                    'echarts/chart/bar' // 使用柱状图就加载bar模块，按需加载
                ],
                function (ec) {
                    // 基于准备好的dom，初始化echarts图表
                    var myChart = ec.init(document.getElementById('main'));

                    var option = {
                        // title : {
                        //     text: '某地区蒸发量和降水量',
                        //     subtext: '纯属虚构'
                        // },
                        tooltip : {
                            trigger: 'axis'
                        },
                        legend: {
                            data:['销售件数','销售金额']
                        },
                        // toolbox: {
                        //     show : true,
                        //     feature : {
                        //         mark : {show: true},
                        //         dataView : {show: true, readOnly: false},
                        //         magicType : {show: true, type: ['line', 'bar']},
                        //         restore : {show: true},
                        //         saveAsImage : {show: true}
                        //     }
                        // },
                        calculable : true,
                        xAxis : [
                            {
                                type : 'category',
                                data : ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月']
                            }
                        ],
                        yAxis : [
                            {
                                type : 'value'
                            }
                        ],
                        series : [that.datas]
                    };
                    // 为echarts对象加载数据
                    myChart.setOption(option);
                }
            );
        }
    }
});